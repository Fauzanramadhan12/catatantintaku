<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class User_login
{
	protected $ci;

	public function __construct()
	{
		$this->ci =& get_instance();
		$this->ci->load->model('m_loginuser');
	}

	public function login($username,$password)
	{
		$cek=$this->ci->m_loginuser->login($username,$password);
		if ($cek) {
			$id_user = $cek->id_user;
			$username  = $cek->username;
			$nama_user = $cek->nama_user;
			$foto_user = $cek->foto_user;
			//buat session
			$this->ci->session->set_userdata('id_user',$id_user);
			$this->ci->session->set_userdata('username',$username);
			$this->ci->session->set_userdata('nama_user',$nama_user);
			$this->ci->session->set_userdata('foto_user',$foto_user);

			redirect('user');
		}else{
			$this->ci->session->set_flashdata('pesan','Username atau Password Salah!!!');
			redirect('login_user');
		}

	}

	public function cek_login()
	{
		if ($this->ci->session->userdata('username')=="") {
			$this->ci->session->set_flashdata('pesan', 'Anda Belum Login!!!');
			redirect('login_user');
		}
	}

	public function logout()
	{
		$this->ci->session->unset_userdata('id_user');
		$this->ci->session->unset_userdata('username');
		$this->ci->session->unset_userdata('nama_user');
		$this->ci->session->set_flashdata('pesan','Logout Sukses!!!');
		redirect('login_user');
	}

	

}

/* End of file LibraryName.php */
