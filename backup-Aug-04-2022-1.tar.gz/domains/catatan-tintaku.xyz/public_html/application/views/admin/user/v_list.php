<main id="main" class="main">

    <div class="pagetitle">
      <h1><?= $title?></h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="<?= base_url('administrator') ?>">HOME</a></li>
          <li class="breadcrumb-item"><?= $title?></li>
        </ol>
      </nav>
    </div><!-- End Page Title -->

    <section class="section">
      <div class="row">
        <div class="col-lg-12">

          <div class="card">
            <div class="card-body">
              <h5 class="card-title"><?= $title?></h5>
			  <a href="<?= base_url('admin_user/add'); ?>" class="btn btn-outline-danger btn-sm"><i class="fa fa-plus"></i> TAMBAHKAN USER</a>
			  <br>
			  <br>
				<?php

				if ($this->session->flashdata('pesan')) {
					echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
						  <i class="bi bi-check-circle me-1"></i>
						  <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>';
					echo $this->session->flashdata('pesan');
					echo '</div>';
				}

				?>

              <!-- Table with stripped rows -->
              <table class="table datatable" id="datatable ">
			  <thead>
		<tr>
			<th width="5px" class="text-center">No</th>
			<th class="text-center">Nama</th>
			<th class="text-center">Foto</th>
			<th width="55px" class="text-center" >Action</th>
		</tr>
	</thead>
	<tbody>
		<?php $no=1; foreach ($user as $key => $value) { ?>
			<tr>
				<td class="text-center"><?= $no++; ?></td>
				<td class="text-center"><?= $value->nama_user ?></td>
				<td class="text-center"><img src="<?= base_url('foto_user/' .$value->foto_user) ?>" width="50px" height="50px"></td>
				<td class="text-center">
				<a href="<?= base_url('admin_user/detail/' .$value->id_user)?>" title="DETAIL" class="btn btn-sm btn-success"><i class="bi bi-info-square-fill"></i></a>
					<a href="<?= base_url('admin_user/edit/' .$value->id_user)?>" title="EDIT" class="btn btn-sm btn-primary"><i class="bi bi-pencil-square"></i></a>
					<a href="<?= base_url('admin_user/delete/' .$value->id_user)?>" onclick="return confirm('Apakah Data Ingin Dihapus..?')" title="HAPUS" class="btn btn-sm btn-danger"><i class="bi bi-trash"></i></a>
				</td>
			</tr>
		<?php } ?>
	</tbody>
              </table>
              <!-- End Table with stripped rows -->

            </div>
          </div>

        </div>
      </div>
    </section>

  </main><!-- End #main -->
