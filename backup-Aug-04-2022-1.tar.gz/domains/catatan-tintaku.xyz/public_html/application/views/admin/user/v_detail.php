<main id="main" class="main">

    <div class="pagetitle">
      <h1><?= $title?></h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="<?= base_url('administrator') ?>">Home</a></li>
		  <li class="breadcrumb-item"><a href="<?= base_url('admin_user') ?>">USER</a></li>
          <li class="breadcrumb-item active">DETAIL USER</li>
        </ol>
      </nav>
    </div><!-- End Page Title -->

	<?php $no=1; foreach ($user as $key => $value) { ?>
    <section class="section profile">
      <div class="row">
        <div class="col-xl-4">

          <div class="card">
            <div class="card-body profile-card pt-4 d-flex flex-column align-items-center">

			<img src="<?= base_url('foto_user/' .$value->foto_user) ?>" alt="Profile">
              <h2><?= $value->nama_user?></h2>
            </div>
          </div>

        </div>

        <div class="col-xl-8">

          <div class="card">
            <div class="card-body pt-3">
              <!-- Bordered Tabs -->
              <ul class="nav nav-tabs nav-tabs-bordered">

                <li class="nav-item">
                  <button class="nav-link active" data-bs-toggle="tab" data-bs-target="#profile-overview">DETAIL</button>
                </li>

              </ul>
              <div class="tab-content pt-2">
				
			  <div class="tab-pane fade show active profile-overview" id="profile-overview">
                 

                  <h5 class="card-title">PROFIL DETAIL</h5>

                  <div class="row">
                    <div class="col-lg-3 col-md-4 label ">Nama</div>
                    <div class="col-lg-9 col-md-8"><?= $value->nama_user?></div>
                  </div>

                  <div class="row">
                    <div class="col-lg-3 col-md-4 label">Username</div>
                    <div class="col-lg-9 col-md-8"><?= $value->username ?></div>
                  </div>

                  <div class="row">
                    <div class="col-lg-3 col-md-4 label">Password</div>
                    <div class="col-lg-9 col-md-8"><?= $value->password ?></div>
                  </div>

                </div>
              </div>

            </div>
          </div>

        </div>
      </div>
    </section>
	<?php } ?>

  </main><!-- End #main -->
