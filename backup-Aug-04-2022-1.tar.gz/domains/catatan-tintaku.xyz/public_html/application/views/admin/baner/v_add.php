<main id="main" class="main">

    <div class="pagetitle">
      <h1><?= $title?></h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="<?= base_url('administrator') ?>">HOME</a></li>
          <li class="breadcrumb-item"><a href="<?= base_url('admin_banner') ?>">BANNER</a></li>
          <li class="breadcrumb-item active">TAMBAH ADD</li>
        </ol>
      </nav>
    </div><!-- End Page Title -->


	<section class="section">
      <div class="row">
        <div class="col-lg-12">

          <div class="card">
            <div class="card-body">
              <h5 class="card-title"></h5>
			  <?php

				echo validation_errors('<div class="alert alert-danger alert-dismissible fade show" role="alert">
				<i class="bi bi-exclamation-octagon me-1"></i>
				<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>', '</div>');

				if (isset($error_upload)) {
					echo '<div class="alert alert-danger alert-dismissible fade show" role="alert">
					<i class="bi bi-exclamation-octagon me-1"></i>
					<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>' .$error_upload. '</div>' ;
				}
				echo form_open_multipart('admin_banner/add');
				?>
              <!-- Vertical Form -->
              <form class="row g-3">
				<div class="row mb-3">
				<label class="col-sm-2 col-form-label">Keterangan</label>
				<div class="col-sm-10">
				<input class="form-control"  type="text" name="keterangan" placeholder="Keterangan">
              	</div>
            	</div>
				
        <div class="row mb-3">
                  <label class="col-sm-2 col-form-label">Foto</label>
                  <div class="col-sm-10">
				  <input type="file" class="form-control" type="text" name="foto_banner" required>
                  </div>
                </div>
                <div class="text-center">
                  <button type="submit" class="btn btn-primary">Submit</button>
                  <button type="reset" class="btn btn-secondary">Reset</button>
                </div>
              </form><!-- Vertical Form -->
			  <?php echo form_close(); ?>

            </div>
          </div>

        </div>
      </div>
    </section>

  </main><!-- End #main -->

