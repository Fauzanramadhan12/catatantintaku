<!-- ======= Sidebar ======= -->
<aside id="sidebar" class="sidebar">

<ul class="sidebar-nav" id="sidebar-nav">

  <li class="nav-item">
	<a class="nav-link " href="<?= base_url('administrator') ?>">
	  <i class="bi bi-grid"></i>
	  <span>DASHBOARD</span>
	</a>
  </li><!-- End Dashboard Nav -->
  <li class="nav-item">
	<a class="nav-link collapsed" data-bs-target="#icons-nav" data-bs-toggle="collapse" href="#">
	  <i class="bi bi-gem"></i><span>CATATAN TINTAKU</span><i class="bi bi-chevron-down ms-auto"></i>
	</a>
	<ul id="icons-nav" class="nav-content collapse " data-bs-parent="#sidebar-nav">
	  <li>
		<a href="<?= base_url('admin_berita/add') ?>">
		  <i class="bi bi-circle"></i><span>ADD CATATAN</span>
		</a>
	  </li>
	  <li>
		<a href="<?= base_url('admin_kategori') ?>">
		  <i class="bi bi-circle"></i><span>KATEGORI</span>
		</a>
	  </li>
	  <li>
		<a href="<?= base_url('admin_berita') ?>">
		  <i class="bi bi-circle"></i><span>LIST CATATAN</span>
		</a>
	  </li>
	</ul>
  </li><!-- End Icons Nav -->

  <li class="nav-item">
	<a class="nav-link collapsed" href="<?= base_url('profil_admin') ?>">
	  <i class="bi bi-person"></i>
	  <span>PROFIL ADMIN</span>
	</a>
  </li><!-- End Profile Page Nav -->

  <li class="nav-item">
	<a class="nav-link collapsed" href="<?= base_url('admin_user') ?>">
	  <i class="bi bi-person"></i>
	  <span>USER</span>
	</a>
  </li><!-- End F.A.Q Page Nav -->

  <li class="nav-item">
	<a class="nav-link collapsed" href="<?= base_url('admin_banner') ?>">
	  <i class="bi bi-envelope"></i>
	  <span>BANNER</span>
	</a>
  </li><!-- End Contact Page Nav -->

  <li class="nav-item">
	<a class="nav-link collapsed" href="<?= base_url('admin_contact') ?>">
	  <i class="bi bi-card-list"></i>
	  <span>CONTACT US</span>
	</a>
  </li><!-- End Register Page Nav -->

  <li class="nav-item">
	<a class="nav-link collapsed" href="<?= base_url('admin_about') ?>">
	  <i class="bi bi-archive"></i>
	  <span>ABOUT</span>
	</a>
  </li><!-- End Login Page Nav -->

</ul>

</aside><!-- End Sidebar-->
