<?php
$this->admin_login->cek_login();
require_once('v_head.php');
require_once('v_header.php');
require_once('v_nav.php');
require_once('v_content.php');
require_once('v_footer.php');
