<main id="main" class="main">

    <div class="pagetitle">
      <h1><?= $title?></h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="<?= base_url('administrator') ?>">HOME</a></li>
		  <li class="breadcrumb-item"><a href="<?= base_url('admin_contact') ?>">CONTACT</a></li>
          <li class="breadcrumb-item active">DETAIL</li>
        </ol>
      </nav>
    </div><!-- End Page Title -->

	<?php $no=1; foreach ($contact as $key => $value) { ?>
    <section class="section profile">
      <div class="row">

        <div class="col-xl-12">

          <div class="card">
            <div class="card-body pt-3">
              <!-- Bordered Tabs -->
              <ul class="nav nav-tabs nav-tabs-bordered">

                <li class="nav-item">
                  <button class="nav-link active" data-bs-toggle="tab" data-bs-target="#profile-overview">DETAIL</button>
                </li>

              </ul>
              <div class="tab-content pt-2">
				
			  <div class="tab-pane fade show active profile-overview" id="profile-overview">
		

                  <div class="row">
                    <div class="col-lg-3 col-md-4 label ">Nama</div>
                    <div class="col-lg-9 col-md-8"><?= $value->nama?></div>
                  </div>

                  <div class="row">
                    <div class="col-lg-3 col-md-4 label">E-mail</div>
                    <div class="col-lg-9 col-md-8"><?= $value->email ?></div>
                  </div>

                  <div class="row">
                    <div class="col-lg-3 col-md-4 label">Tema / Subject</div>
                    <div class="col-lg-9 col-md-8"><?= $value->subjek ?></div>
                  </div>

									<div class="row">
                    <div class="col-lg-3 col-md-4 label">Isi</div>
                    <div class="col-lg-9 col-md-8"><?= $value->isi ?></div>
                  </div>

                </div>
              </div>

            </div>
          </div>

        </div>
      </div>
    </section>
	<?php } ?>

  </main><!-- End #main -->
