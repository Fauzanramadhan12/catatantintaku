<main id="main" class="main">

    <div class="pagetitle">
      <h1><?= $title?></h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="<?= base_url('administrator') ?>">HOME</a></li>
          <li class="breadcrumb-item"><?= $title?></li>
        </ol>
      </nav>
    </div><!-- End Page Title -->

    <section class="section">
      <div class="row">
        <div class="col-lg-12">

          <div class="card">
            <div class="card-body">
              <h5 class="card-title"><?= $title?></h5>
			  <br>
			  <br>
				<?php

				if ($this->session->flashdata('pesan')) {
					echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
						  <i class="bi bi-check-circle me-1"></i>
						  <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>';
					echo $this->session->flashdata('pesan');
					echo '</div>';
				}

				?>

              <!-- Table with stripped rows -->
              <table class="table datatable" id="datatable ">
			  <thead>
		<tr>
			<th width="5px" class="text-center">No</th>
			<th class="text-center">Nama</th>
			<th class="text-center">Email</th>
			<th width="55px" class="text-center" >Action</th>
		</tr>
	</thead>
	<tbody>
		<?php $no=1; foreach ($contact as $key => $value) { ?>
			<tr>
				<td class="text-center"><?= $no++; ?></td>
				<td class="text-center"><?= $value->nama; ?></td>
				<td class="text-center"><?= $value->email ?></td>
				<td>
					<a href="<?= base_url('admin_contact/detail/' .$value->id_contact)?>" title="DETAIL" class="btn btn-sm btn-primary"><i class="bi bi-info-square-fill"></i></a>
				</td>
			</tr>
		<?php } ?>
	</tbody>

              </table>
              <!-- End Table with stripped rows -->

            </div>
          </div>

        </div>
      </div>
    </section>

  </main><!-- End #main -->
