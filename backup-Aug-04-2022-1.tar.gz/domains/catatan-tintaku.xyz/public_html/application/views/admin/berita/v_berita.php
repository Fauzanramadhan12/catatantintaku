<main id="main" class="main">

    <div class="pagetitle">
      <h1><?= $title?></h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="<?= base_url('administrator') ?>">HOME</a></li>
          <li class="breadcrumb-item"><?= $title?></li>
        </ol>
      </nav>
    </div><!-- End Page Title -->

    <section class="section">
      <div class="row">
        <div class="col-lg-12">

          <div class="card">
            <div class="card-body">
              <h5 class="card-title"><?= $title?></h5>
			  <a href="<?= base_url('admin_berita/add'); ?>" class="btn btn-outline-danger btn-sm"><i class="fa fa-plus"></i> TAMBAH ARTIKEL</a>
			  <br>
			  <br>
				<?php

				if ($this->session->flashdata('pesan')) {
					echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
						  <i class="bi bi-check-circle me-1"></i>
						  <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>';
					echo $this->session->flashdata('pesan');
					echo '</div>';
				}

				?>

              <!-- Table with stripped rows -->
              <table class="table datatable" id="datatable ">
			  <thead>
		<tr>
			<th width="1px" class="text-center">No</th>
			<th class="text-center">Judul</th>
			<th class="text-center" >Foto</th>
			<th width="45px" class="text-center">Action</th>
		</tr>
	</thead>
	<tbody>
		<?php $no=1; foreach ($berita as $key => $value) { ?>
			<tr>
				<td><?= $no++; ?></td>
				<td><?= $value->judul_berita ?></td>
				<td class="text-center"><img src="<?= base_url('foto_berita/' .$value->foto_berita) ?>" width="20%"></td>
				<td>
				<a href="<?= base_url('admin_berita/detail/' .$value->id_berita)?>" title="DETAIL" class="btn btn-sm btn-success"><i class="bi bi-info-square-fill"></i></a>
					<a href="<?= base_url('admin_berita/edit/' .$value->id_berita)?>" title="EDIT" class="btn btn-sm btn-primary"><i class="bi bi-pencil-square"></i></a>
					<a href="<?= base_url('admin_berita/delete/' .$value->id_berita)?>" onclick="return confirm('Apakah Artikel Ingin Dihapus..?')" title="HAPUS" class="btn btn-sm btn-danger"><i class="bi bi-trash"></i></a>
				</td>
			</tr>
		<?php } ?>
	</tbody>

              </table>
              <!-- End Table with stripped rows -->

            </div>
          </div>

        </div>
      </div>
    </section>

  </main><!-- End #main -->
