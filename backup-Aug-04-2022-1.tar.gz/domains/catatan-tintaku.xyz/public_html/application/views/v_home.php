

<!-- Page Content -->
    <!-- Banner Starts Here -->
    <div class="main-banner header-text">
      <div class="container-fluid">
        <div class="owl-banner owl-carousel">
					<?php foreach ($berita_slider as $key => $value) { ?>
          <div class="item">
            <img src="<?= base_url('foto_berita/' .$value->foto_berita) ?>" alt="">
            <div class="item-content">
              <div class="main-content">
                <div class="meta-category">
                  <span><?= $value->nama_kategori ?></span>
                </div>
                <a href="<?= base_url('artikel/detail_artikel/' .$value->slug_berita) ?>"><h4><?= substr(strip_tags($value->judul_berita),0,50)?></h4></a>
                <ul class="post-info">
                  <li><a href="#"><?= $value->nama_admin ?> <?= $value->nama_user ?></a></li>
                  <li><a href="#"><?= $value->tgl_berita ?></a></li>
									
                </ul>
              </div>
            </div>
          </div>
					<?php } ?>
        </div>
      </div>
    </div>
    <!-- Banner Ends Here -->

<?php foreach ($banner as $key => $value) { ?>
		<style>
			.call-to-action .main-content {
				padding: 40px;
				background-image: url(<?= base_url('foto_banner/' .$value->foto_banner) ?>);
				background-position: center center;
				background-repeat: no-repeat;
				background-size: cover;
			}
		</style>

    <section class="call-to-action">
      <div class="container">
        <div class="row">
          <div class="col-lg-12">
            <div class="main-content">
              <div class="row">
                <div class="col-lg-8">
                  <span></span>
                  <h4></h4>
                </div>
                <div class="col-lg-4">
                  <div class="main-button">
                    <br>
										<br>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
<?php } ?>


    <section class="blog-posts">
      <div class="container">
        <div class="row">
          <div class="col-lg-8">
            <div class="all-blog-posts">
              <div class="row">
								<?php foreach ($home_berita as $key => $value) { ?>
                <div class="col-lg-12">
                  <div class="blog-post">
                    <div class="blog-thumb">
                      <img src="<?= base_url('foto_berita/' .$value->foto_berita) ?>" alt="">
                    </div>
                    <div class="down-content">
                      <span><?= $value->nama_kategori ?></span>
                      <a href="<?= base_url('artikel/detail_artikel/' .$value->slug_berita) ?>"><h4><?= $value->judul_berita ?></h4></a>
                      <ul class="post-info">
											<li><a href="#"><?= $value->nama_admin ?> <?= $value->nama_user ?></a></li>
                  		<li><a href="#"><?= $value->tgl_berita ?></a></li>
                      </ul>
                      <p>	<?= substr(strip_tags($value->isi_berita),0,350)?>...</p>
                      <div class="post-options">
                        <div class="row">
                          <div class="col-6">
                            <ul class="post-tags">
                              <li><i class="fa fa-tags"></i></li>
                              <li><a href="#"><?= $value->nama_kategori ?></a></li>
                            </ul>
                          </div>
                          <div class="col-6">
                            
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <?php } ?>
                <div class="col-lg-12">
                  <div class="main-button">
                    <a href="<?= base_url('artikel') ?>">View All Posts</a>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="col-lg-4">
            <div class="sidebar">
              <div class="row">
                <div class="col-lg-12">
                  <div class="sidebar-item recent-posts">
                    <div class="sidebar-heading">
                      <h2>ARTIKEL TERPOPULER</h2>
                    </div>
                    <div class="content">
                      <ul>
												<?php foreach ($populer_berita as $key => $value) { ?>
                        <li><a href="<?= base_url('artikel/detail_artikel/' .$value->slug_berita) ?>">
                          <h5><?= substr(strip_tags($value->judul_berita),0,50)?></h5>
                          <span><?= $value->tgl_berita ?></span>
                        </a></li>
												<?php } ?>
                      </ul>
                    </div>
                  </div>
                </div>

								<div class="col-lg-12">
                  <div class="sidebar-item recent-posts">
                    <div class="sidebar-heading">
                      <h2>ARTIKEL TERBARU</h2>
                    </div>
                    <div class="content">
                      <ul>
												<?php foreach ($terbaru_berita as $key => $value) { ?>
                        <li><a href="<?= base_url('artikel/detail_artikel/' .$value->slug_berita) ?>">
                          <h5><?= substr(strip_tags($value->judul_berita),0,50)?></h5>
                          <span><?= $value->tgl_berita ?></span>
                        </a></li>
												<?php } ?>
                      </ul>
                    </div>
                  </div>
                </div>


                <div class="col-lg-12">
                  <div class="sidebar-item categories">
                    <div class="sidebar-heading">
                      <h2>Categories</h2>
                    </div>
                    <div class="content">
                      <ul>
												<?php foreach ($kategori as $key => $value) { ?>
                        <li><a href="<?= base_url('artikel/kategori/' .$value->id_kategori) ?>">- <?= $value->nama_kategori ?></a></li>
												<?php } ?>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
