<style>
		.page-heading {
	margin: 0px 10px;
	padding: 120px 0px;
	text-align: left;
	background-position: center center;
	background-repeat: no-repeat;
	background-size: cover;
	background-image: url(<?= base_url('template/bg1.jpg') ?>);
}
</style>
<!-- Page Content -->
    <!-- Banner Starts Here -->
    <div class="heading-page header-text">
      <section class="page-heading">
        <div class="container">
          <div class="row">
            <div class="col-lg-12">
              <div class="text-content">
                <h4>ARTIKEL</h4>
                <h2><?= $title ?></h2>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
    
    <!-- Banner Ends Here -->

    <?php foreach ($banner as $key => $value) { ?>
		<style>
			.call-to-action .main-content {
				padding: 40px;
				background-image: url(<?= base_url('foto_banner/' .$value->foto_banner) ?>);
				background-position: center center;
				background-repeat: no-repeat;
				background-size: cover;
			}
		</style>

    <section class="call-to-action">
      <div class="container">
        <div class="row">
          <div class="col-lg-12">
            <div class="main-content">
              <div class="row">
                <div class="col-lg-8">
                  <span></span>
                  <h4></h4>
                </div>
                <div class="col-lg-4">
                  <div class="main-button">
                    <br>
										<br>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
<?php } ?>

    <section class="blog-posts grid-system">
      <div class="container">
        <div class="row">
          <div class="col-lg-8">
            <div class="all-blog-posts">
              <div class="row">
				  <?php foreach ($berita as $key => $value) { ?>
						<?php
									require_once('application/controllers/db_connect.php'); // Database connection file
									require_once('application/controllers/functions.php');  // PHP functions file

									$page_id = $value->id_berita;
									$visitor_ip = $_SERVER['REMOTE_ADDR']; // stores IP address of visitor in variable

									add_view($conn, $visitor_ip, $page_id);
									?>
                <div class="col-lg-6">
                  <div class="blog-post">
                    <div class="blog-thumb">
                      <img src="<?= base_url('foto_berita/' .$value->foto_berita) ?>" alt="">
                    </div>
                    <div class="down-content">
                      <span><?= $value->nama_kategori ?></span>
                      <a href="<?= base_url('artikel/detail_artikel/' .$value->slug_berita) ?>"><h4><?= substr(strip_tags($value->judul_berita),0,50)?>...</h4></a>
                      <ul class="post-info">
                        <li><a href="#"><?= $value->nama_admin ?> <?= $value->nama_user ?></a></li>
                        <li><a href="#"><?= $value->tgl_berita ?></a></li>
                        <li><a href="#"><?php
												$total_page_views = total_views($conn, $page_id); // Returns total views of this page
												echo "  " . $total_page_views; echo " View";
												?></a></li>
                      </ul>
                      <p><?= substr(strip_tags($value->isi_berita),0,250)?>...</p>
                      <div class="post-options">
                        <div class="row">
                          <div class="col-lg-12">
                            <ul class="post-tags">
                              <li><i class="fa fa-tags"></i></li>
                              <li><a href="<?= base_url('artikel/kategori/' .$value->id_kategori) ?>"><?= $value->nama_kategori ?></a></li>
                            </ul>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
				<?php } ?>
                <div class="col-lg-12">
				<?php
					if (isset($paginasi)) {
						echo $paginasi;
					}
				?>
                </div>
              </div>
            </div>
          </div>
          <div class="col-lg-4">
            <div class="sidebar">
              <div class="row">
                
                <div class="col-lg-12">
                  <div class="sidebar-item recent-posts">
                    <div class="sidebar-heading">
                      <h2>ARTIKEL TERPOPULER</h2>
                    </div>
                    <div class="content">
                      <ul>
						<?php foreach ($populer_berita as $key => $value) { ?>
                        <li><a href="<?= base_url('artikel/detail_artikel/' .$value->slug_berita) ?>">
                          <h5><?= substr(strip_tags($value->judul_berita),0,50)?>...</h5>
                          <span><?= $value->tgl_berita ?></span>
                        </a></li>
						<?php } ?>
                      </ul>
                    </div>
                  </div>
                </div>
				<div class="col-lg-12">
                  <div class="sidebar-item recent-posts">
                    <div class="sidebar-heading">
                      <h2>ARTIKEL TERBARU</h2>
                    </div>
                    <div class="content">
                      <ul>
						<?php foreach ($terbaru_berita as $key => $value) { ?>
                        <li><a href="<?= base_url('artikel/detail_artikel/' .$value->slug_berita) ?>">
                          <h5><?= substr(strip_tags($value->judul_berita),0,50)?>...</h5>
                          <span><?= $value->tgl_berita ?></span>
                        </a></li>
						<?php } ?>
                      </ul>
                    </div>
                  </div>
                </div>
                <div class="col-lg-12">
                  <div class="sidebar-item categories">
                    <div class="sidebar-heading">
                      <h2>Categories</h2>
                    </div>
                    <div class="content">
                      <ul>
						<?php foreach ($kategori as $key => $value) { ?>
                        <li><a href="<?= base_url('artikel/kategori/' .$value->id_kategori) ?>">- <?= $value->nama_kategori ?></a></li>
						<?php } ?>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
