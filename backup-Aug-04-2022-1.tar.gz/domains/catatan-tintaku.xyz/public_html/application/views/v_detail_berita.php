<style>
		.page-heading {
	margin: 0px 10px;
	padding: 120px 0px;
	text-align: left;
	background-position: center center;
	background-repeat: no-repeat;
	background-size: cover;
	background-image: url(<?= base_url('template/bg1.jpg') ?>);
}

.blog-posts .down-content p {
  padding: 16px 0px;
  margin: -18px 0px;
  border-top: 0px solid #eee;
  border-bottom: 0px solid #eee;
}
</style>
<!-- Page Content -->
    <!-- Banner Starts Here -->
    <div class="heading-page header-text">
      <section class="page-heading">
        <div class="container">
          <div class="row">
            <div class="col-lg-12">
              <div class="text-content">
							<h4>Catatan Tintaku</h4>
                <h2>Selamat Membaca</h2>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
    
    <!-- Banner Ends Here -->

	<?php foreach ($banner as $key => $value) { ?>
		<style>
			.call-to-action .main-content {
				padding: 40px;
				background-image: url(<?= base_url('foto_banner/' .$value->foto_banner) ?>);
				background-position: center center;
				background-repeat: no-repeat;
				background-size: cover;
			}
		</style>

    <section class="call-to-action">
      <div class="container">
        <div class="row">
          <div class="col-lg-12">
            <div class="main-content">
              <div class="row">
                <div class="col-lg-8">
                  <span></span>
                  <h4></h4>
                </div>
                <div class="col-lg-4">
                  <div class="main-button">
                    <br>
					<br>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
<?php } ?>

<?php
require_once('application/controllers/db_connect.php'); // Database connection file
require_once('application/controllers/functions.php');  // PHP functions file

$page_id = $berita->id_berita;
$visitor_ip = $_SERVER['REMOTE_ADDR']; // stores IP address of visitor in variable

add_view($conn, $visitor_ip, $page_id);
?>

    <section class="blog-posts grid-system">
      <div class="container">
        <div class="row">
          <div class="col-lg-8">
            <div class="all-blog-posts">
              <div class="row">
                <div class="col-lg-12">
                  <div class="blog-post">
                    <div class="blog-thumb">
                      <img src="<?= base_url('foto_berita/' .$berita->foto_berita) ?>" alt="">
                    </div>
                    <div class="down-content">
										<div class="sharethis-inline-share-buttons"></div>
										<br>
                      <span><?= $berita->nama_kategori ?></span>
                      <a href="#"><h4><?= $berita->judul_berita ?></h4></a>
                      <ul class="post-info">
                        <li><a href="#"><?= $berita->nama_admin ?> <?= $berita->nama_user ?></a></li>
                        <li><a href="#"><?= $berita->nama_kategori ?></a></li>
                        <li><a href="#"><?php
								$total_page_views = total_views($conn, $page_id); // Returns total views of this page
								 echo "  " . $total_page_views; echo " Lihat";
								?></a></li>
                      </ul>
					  <hr>
                      <h6><?= $berita->isi_berita ?></h6>
					  <hr>
                      <div class="post-options">
                        <div class="row">
                          <div class="col-6">
                            <ul class="post-tags">
                              <li><i class="fa fa-tags"></i></li>
                              <li><a href="#"><?= $berita->nama_kategori ?></a></li>
                            </ul>
                          </div>
                          <div class="col-6">
                            <ul class="post-share">
                              
                            </ul>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
								<!-- ShareThis BEGIN --><div class="sharethis-inline-reaction-buttons"></div><!-- ShareThis END -->
                <div class="col-lg-12">
                  <div class="sidebar-item comments">
                    <div class="sidebar-heading">
                    </div>
                    <div class="content">
                      <ul>
                        <li>
						<div>
							<p> Diupload Oleh :</p>
							<br>
						</div>
                          <div class="author-thumb">
						  <img src="<?= base_url('foto_user/' .$berita->foto_user) ?>"  alt="">
							<img src="<?= base_url('foto_admin/' .$berita->foto_admin) ?>" alt="">
                          </div>
                          <div class="right-content">
                            <h4><?= $berita->nama_user ?> <?= $berita->nama_admin ?></h4>
                            <p></p>
                          </div>
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="col-lg-4">
            <div class="sidebar">
              <div class="row">
                <div class="col-lg-12">
                  <div class="sidebar-item recent-posts">
                    <div class="sidebar-heading">
                      <h2>ARTIKEL TERPOPULER</h2>
                    </div>
                    <div class="content">
                      <ul>
						<?php foreach ($populer_berita as $key => $value) { ?>
                        <li><a href="<?= base_url('artikel/detail_artikel/' .$value->slug_berita) ?>">
                          <h5><?= substr(strip_tags($value->judul_berita),0,50)?></h5>
                          <span><?= $value->tgl_berita ?></span>
                        </a></li>
						<?php } ?>
                      </ul>
                    </div>
                  </div>
                </div>
				<div class="col-lg-12">
                  <div class="sidebar-item recent-posts">
                    <div class="sidebar-heading">
                      <h2>ARTIKEL TERBARU</h2>
                    </div>
                    <div class="content">
                      <ul>
						<?php foreach ($terbaru_berita as $key => $value) { ?>
                        <li><a href="<?= base_url('artikel/detail_artikel/' .$value->slug_berita) ?>">
                          <h5><?= substr(strip_tags($value->judul_berita),0,50)?></h5>
                          <span><?= $value->tgl_berita ?></span>
                        </a></li>
						<?php } ?>
                      </ul>
                    </div>
                  </div>
                </div>
                <div class="col-lg-12">
                  <div class="sidebar-item categories">
                    <div class="sidebar-heading">
                      <h2>Categories</h2>
                    </div>
                    <div class="content">
                      <ul>
						<?php foreach ($kategori as $key => $value) { ?>
                        <li><a href="<?= base_url('artikel/kategori/' .$value->id_kategori) ?>">- <?= $value->nama_kategori ?></a></li>
						<?php } ?>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
