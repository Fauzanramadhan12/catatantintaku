<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Catatan Tintaku">
    <meta name="author" content="Catatan Tintaku">
    <link href="https://fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i&display=swap" rel="stylesheet">

	<link href="<?= base_url() ?>template/Untitled-1.png" rel="">

    <title><?= $title ?> - Catatan Tintaku </title>

    <!-- Bootstrap core CSS -->
    <link href="<?= base_url() ?>template/frond/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">


    <!-- Additional CSS Files -->
    <link rel="stylesheet" href="<?= base_url() ?>template/frond/assets/css/fontawesome.css">
    <link rel="stylesheet" href="<?= base_url() ?>template/frond/assets/css/templatemo-stand-blog.css">
    <link rel="stylesheet" href="<?= base_url() ?>template/frond/assets/css/owl.css">
<!--

TemplateMo 551 Stand Blog

https://templatemo.com/tm-551-stand-blog

-->
  </head>
