<style>
	.navbar .navbar-brand h2 {
  color: #1e1e1e;
  text-transform: uppercase;
  font-size: 17px;
  font-weight: 900;
  -webkit-transition: all .3s ease 0s;
  -moz-transition: all .3s ease 0s;
  -o-transition: all .3s ease 0s;
  transition: all .3s ease 0s;
}
</style>
 <!-- Header -->
<header class="">
	<nav class="navbar navbar-expand-lg">
		<div class="container">
			<a class="navbar-brand" href="<?= base_url('home') ?>"><h2>Catatan Tintaku<em>.</em></h2></a>
			<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
				<span class="navbar-toggler-icon"></span>
			</button>
			<div class="collapse navbar-collapse" id="navbarResponsive">
				<ul class="navbar-nav ml-auto">
					<li class="nav-item">
						<a class="nav-link" href="<?= base_url('home') ?>">Home
							<span class="sr-only">(current)</span>
						</a>
					</li> 
					<li class="nav-item">
						<a class="nav-link" href="<?= base_url('about') ?>">About Us</a>
					</li>
					<li class="nav-item">
						<a class="nav-link" href="<?= base_url('artikel') ?>">Artikel</a>
					</li>
					<li class="nav-item">
						<a class="nav-link" href="<?= base_url('contact') ?>">Contact Us</a>
					</li>
				</ul>
			</div>
		</div>
	</nav>
</header>
