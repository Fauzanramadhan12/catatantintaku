<style>
  .navbar .navbar-brand h2 {
  color: #1e1e1e;
  text-transform: uppercase;
  font-size: 17px;
  font-weight: 900;
  -webkit-transition: all .3s ease 0s;
  -moz-transition: all .3s ease 0s;
  -o-transition: all .3s ease 0s;
  transition: all .3s ease 0s;
}
	.page-heading {
	margin: 0px 10px;
	padding: 120px 0px;
	text-align: left;
	background-position: center center;
	background-repeat: no-repeat;
	background-size: cover;
	background-image: url(<?= base_url('template/bg1.jpg') ?>);
}
</style>

<div class="heading-page header-text">
      <section class="page-heading">
        <div class="container">
          <div class="row">
            <div class="col-lg-12">
              <div class="text-content">
                <h4>about us</h4>
                <h2>Catatan Tintaku</h2>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
    
    <!-- Banner Ends Here -->


    <section class="about-us">
      <div class="container">
      	<?php foreach ($about as $key => $value) { ?>
        <div class="row">
          <div class="col-lg-12">
            <img src="<?= base_url('foto_about/' .$value->foto_about) ?>" width="15%">
            <h2><?= $value->isi ?></h2>
          </div>
        </div>
        
        <div class="row">
          <div class="col-lg-12">
            
          </div>
        </div>
        
      <?php } ?>
      </div>
    </section>
