<main id="main" class="main">

<marquee behavior="" direction=""> <h2>Selamat Datang Di Halaman USER <b>Catatan Tintaku</b> <?= $this->session->userdata('nama_user'); ?> </h2></marquee>
  
<h4>Hallo <?= $this->session->userdata('nama_user'); ?> </h4>
    <div class="pagetitle">
		<?php 
    $tanggal = mktime(date('m'), date("d"), date('Y'));
    echo "Hari Ini Tanggal : <b> " . date("d-m-Y", $tanggal ) . "</b>";
    date_default_timezone_set("Asia/Jakarta");
    $jam = date ("H:i:s");
    echo " | Pukul : <b> " . $jam . " " ." </b> ";
    $a = date ("H");
    if (($a>=6) && ($a<=11)) {
        echo " <b>, Selamat Pagi !! </b>";
    }else if(($a>=11) && ($a<=15)){
        echo " , Selamat  Pagi !!";
    }elseif(($a>15) && ($a<=18)){
        echo ", Selamat Siang !!";
    }else{
        echo ", <b> Selamat Malam </b>" ;
    }
     
 ?>
 <br>
    <div class="pagetitle">
      <h1>DASHBOARD</h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="<?= base_url('user') ?>">HOME</a></li>
          <li class="breadcrumb-item active">DASHBOARD</li>
        </ol>
      </nav>
    </div><!-- End Page Title -->

    <section class="section dashboard">
      <div class="row">

        <!-- Left side columns -->
        <div class="col-lg-8">
          <div class="row">

            <!-- Sales Card -->
            <div class="col-xxl-8 col-md-12">
              <div class="card info-card sales-card">

                <div class="filter">
                  <a class="icon" href="#" data-bs-toggle="dropdown"><i class="bi bi-three-dots"></i></a>
                  <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow">
                    <li class="dropdown-header text-start">
                      <h6>Filter</h6>
                    </li>

                    <li><a class="dropdown-item" href="<?= base_url('user_berita/add') ?>">TAMBAH CATATAN</a></li>
                    <li><a class="dropdown-item" href="<?= base_url('user_berita') ?>">LIST CATATAN</a></li>
                  </ul>
                </div>

                <div class="card-body">
                  <h5 class="card-title">ARTIKEL <span>| CATATAN TINTAKU </span></h5>

                  <div class="d-flex align-items-center">
                    <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                      <i class="bi bi-receipt-cutoff"></i>
                    </div>
                    <div class="ps-3">
                      <h6>ARTIKEL</h6>
											<span class="text-danger small pt-1 fw-bold"><?= $total_berita ?></span> <span class="text-muted small pt-2 ps-1">TOTAL CATATAN KAMU</span>
                    </div>
                  </div>
                </div>

              </div>
            </div><!-- End Sales Card -->

            <!-- Revenue Card -->
            

			<!-- Revenue Card -->
            

			<!-- Revenue Card -->
            

			<!-- Revenue Card -->
            
			<!-- Revenue Card -->
            
			<!-- Revenue Card -->
            
			<!-- Revenue Card -->
            
          </div>
        </div><!-- End Left side columns -->

        <!-- Right side columns -->
        <div class="col-lg-4">

          <!-- Recent Activity -->
          <div class="card">
            <div class="filter">
            </div>

            <div class="card-body">
              <h5 class="card-title">PROFIL <span>| USER</span></h5>
							<div class="text-center">
							<img src="<?= base_url('foto_user/'. $this->session->userdata('foto_user')) ?>" width="50%">
							<br>
							<br>
							<h3> <b><i class="fa fa-user fa-fw"></i> <?= $this->session->userdata('nama_user'); ?></b></h3>
							<h5>USER</h5>
							</div>
            </div>
          </div><!-- End Recent Activity -->

        </div><!-- End Right side columns -->

      </div>
    </section>

  </main><!-- End #main -->
