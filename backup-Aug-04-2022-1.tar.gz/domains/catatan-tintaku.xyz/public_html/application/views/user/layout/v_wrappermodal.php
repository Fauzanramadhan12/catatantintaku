<?php
$this->user_login->cek_login();
require_once('v_headmodal.php');
require_once('v_header.php');
require_once('v_nav.php');
require_once('v_content.php');
require_once('v_footer.php');
