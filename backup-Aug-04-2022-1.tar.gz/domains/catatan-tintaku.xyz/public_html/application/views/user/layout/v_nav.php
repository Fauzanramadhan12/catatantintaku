<!-- ======= Sidebar ======= -->
<aside id="sidebar" class="sidebar">

<ul class="sidebar-nav" id="sidebar-nav">

  <li class="nav-item">
	<a class="nav-link " href="<?= base_url('user') ?>">
	  <i class="bi bi-grid"></i>
	  <span>DASHBOARD</span>
	</a>
  </li><!-- End Dashboard Nav -->
  <li class="nav-item">
	<a class="nav-link collapsed" data-bs-target="#icons-nav" data-bs-toggle="collapse" href="#">
	  <i class="bi bi-gem"></i><span>CATATAN TINTAKU</span><i class="bi bi-chevron-down ms-auto"></i>
	</a>
	<ul id="icons-nav" class="nav-content collapse " data-bs-parent="#sidebar-nav">
	  <li>
		<a href="<?= base_url('user_berita/add') ?>">
		  <i class="bi bi-circle"></i><span>ADD CATATAN</span>
		</a>
	  </li>
	  <li>
		<a href="<?= base_url('user_kategori') ?>">
		  <i class="bi bi-circle"></i><span>KATEGORI</span>
		</a>
	  </li>
	  <li>
		<a href="<?= base_url('user_berita') ?>">
		  <i class="bi bi-circle"></i><span>LIST CATATAN</span>
		</a>
	  </li>
	</ul>
  </li><!-- End Icons Nav -->

  <li class="nav-item">
	<a class="nav-link collapsed" href="<?= base_url('profil_user') ?>">
	  <i class="bi bi-person"></i>
	  <span>PROFIL USER</span>
	</a>
  </li><!-- End Profile Page Nav -->

</ul>

</aside><!-- End Sidebar-->
