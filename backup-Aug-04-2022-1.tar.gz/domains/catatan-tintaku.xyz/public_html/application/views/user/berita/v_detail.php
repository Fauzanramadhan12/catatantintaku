<main id="main" class="main">

    <div class="pagetitle">
      <h1><?= $title?></h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="<?= base_url('user') ?>">HOME</a></li>
		  <li class="breadcrumb-item"><a href="<?= base_url('user_berita') ?>">ARTIKEL</a></li>
          <li class="breadcrumb-item active">DETAIL ARTIKEL</li>
        </ol>
      </nav>
    </div><!-- End Page Title -->

	<?php $no=1; foreach ($berita as $key => $value) { ?>
    <section class="section profile">
      <div class="row">

        <div class="col-xl-12">

          <div class="card">
            <div class="card-body pt-3">
              <!-- Bordered Tabs -->
              <ul class="nav nav-tabs nav-tabs-bordered">

                <li class="nav-item">
                  <button class="nav-link active" data-bs-toggle="tab" data-bs-target="#profile-overview">DETAIL</button>
                </li>

              </ul>
              <div class="tab-content pt-2">
				
			  <div class="tab-pane fade show active profile-overview" id="profile-overview">
                 

                  <h5 class="card-title">DETAILS ARTIKEL</h5>

                  <div class="row">
                    <div class="col-lg-3 col-md-4 label ">Judul Berita</div>
                    <div class="col-lg-9 col-md-8"><?= $value->judul_berita ?></div>
                  </div>

                  <div class="row">
                    <div class="col-lg-3 col-md-4 label">Tanggal Rilis</div>
                    <div class="col-lg-9 col-md-8"><?= $value->tgl_berita ?></div>
                  </div>

                  <div class="row">
                    <div class="col-lg-3 col-md-4 label">Upload Oleh</div>
                    <div class="col-lg-9 col-md-8"><?= $value->nama_admin ?> <?= $value->nama_user ?></div>
                  </div>

                  <div class="row">
                    <div class="col-lg-3 col-md-4 label">Kategori</div>
                    <div class="col-lg-9 col-md-8"><?= $value->nama_kategori ?></div>
                  </div>

                  <div class="row">
                    <div class="col-lg-3 col-md-4 label">Isi Berita</div>
                    <div class="col-lg-9 col-md-8"><?= $value->isi_berita ?></div>
                  </div>
                </div>
              </div>

            </div>
          </div>

        </div>
      </div>
    </section>
	<?php } ?>

  </main><!-- End #main -->
