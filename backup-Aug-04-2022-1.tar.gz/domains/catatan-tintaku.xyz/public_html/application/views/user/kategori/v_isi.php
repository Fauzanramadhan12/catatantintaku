<main id="main" class="main">

    <div class="pagetitle">
      <h1><?= $title?></h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="<?= base_url('user') ?>">HOME</a></li>
          <li class="breadcrumb-item"><?= $title?></li>
        </ol>
      </nav>
    </div><!-- End Page Title -->

    <section class="section">
      <div class="row">
        <div class="col-lg-12">

          <div class="card">
            <div class="card-body">
              <h5 class="card-title"><?= $title?></h5>
			  <button type="button" class="btn btn-outline-danger btn-sm" data-bs-toggle="modal" data-bs-target="#basicModal">
                TAMBAHKAN KATEGORI
              </button>
			  <br>
			  <br>
				<?php

				if ($this->session->flashdata('pesan')) {
					echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
						  <i class="bi bi-check-circle me-1"></i>
						  <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>';
					echo $this->session->flashdata('pesan');
					echo '</div>';
				}

				?>

              <!-- Table with stripped rows -->
              <table class="table datatable" id="datatable ">
			  <thead>
		<tr>
			<th width="5px" class="text-center">No</th>
			<th class="text-center">Kategori</th>
			<th width="155px" class="text-center">Action</th>
		</tr>
	</thead>
	<tbody>
		<?php $no=1; foreach ($kategori as $key => $value) { ?>
			<tr>
				<td><?= $no++; ?></td>
				<td><?= $value->nama_kategori ?></td>
				<td class="text-center">
				<button type="button" class="btn btn-sm btn-success" data-bs-toggle="modal" data-bs-target="#edit<?= $value->id_kategori ?>">Edit </button>
					<a href="<?= base_url('user_kategori/delete/' .$value->id_kategori)?>" onclick="return confirm('Apakah Kategori Ingin Dihapus..?')" class="btn btn-sm btn-danger"><i class="fa fa-trash"> Hapus</i></a>
				</td>
			</tr>
		<?php } ?>
	</tbody>
              </table>
              <!-- End Table with stripped rows -->

            </div>
          </div>

        </div>
      </div>
    </section>

  </main><!-- End #main -->

<!-- Basic Modal -->
	</button>
	<div class="modal fade" id="basicModal" tabindex="-1">
	<div class="modal-dialog">
		<div class="modal-content">
		<div class="modal-header">
			<h5 class="modal-title">Tambah Data</h5>
			<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
		</div>
		<div class="modal-body">
		<?php echo form_open('user_kategori/add') ?>
		<div class="form-group">
		<label>Kategori</label>
		<input class="form-control" type="text" name="nama_kategori" placeholder="Nama Kategori" required>
		</div>
		</div>
		<div class="modal-footer">
		<button type="close" class="btn btn-default" data-dismiss="modal">Close</button>
		<button type="submit" class="btn btn-primary">Simpan</button>
		</div>
		<?php echo form_close() ?>
	</div>
	</div>
	</div><!-- End Basic Modal-->

	<?php foreach ($kategori as $key => $value) { ?>
	</button>
	<div class="modal fade" id="edit<?= $value->id_kategori?>" tabindex="-1">
	<div class="modal-dialog">
		<div class="modal-content">
		<div class="modal-header">
			<h5 class="modal-title">EDIT KATEGORI</h5>
			<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
		</div>
		<div class="modal-body">
		<?php echo form_open('user_kategori/edit/' .$value->id_kategori) ?>
		<div class="form-group">
		<label>Kategori</label>
		<input class="form-control" type="text" value="<?= $value->nama_kategori ?>" name="nama_kategori" placeholder="Nama Kategori" required>
		</div>
		</div>
		<div class="modal-footer">
		<button type="close" class="btn btn-default" data-dismiss="modal">Close</button>
		<button type="submit" class="btn btn-primary">Simpan</button>
		</div>
		<?php echo form_close() ?>
	</div>
	</div>
	</div><!--
		 End Basic Modal-->
	<?php } ?>
