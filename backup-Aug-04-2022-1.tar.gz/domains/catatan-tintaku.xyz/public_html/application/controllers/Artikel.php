<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Artikel extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('m_home');
	}

	public function index()
	{
		$this->load->library('pagination');
		$config['base_url'] = base_url('artikel/index');
		$config['total_rows'] = count($this->m_home->total_berita());
		$config['per_page'] = 8;
		$config['uri_segmen'] = 3;
		//start dan limit
			$limit= $config['per_page'];
			$start= ($this->uri->segment(3)) ? ($this->uri->segment(3)) : 0;
		//-------------------
		$config['first_link'] 		= 'First';
		$config['last_link'] 		= 'Last';
		$config['next_link'] 		= 'Next';
		$config['prev_link'] 		= 'Prev';
		$config['full_tag_open']	= '<div class="col-lg-12" ><ul class="page-numbers">';
		$config['num_tag_open'] 	= '<li>';
		$config['num_tag_close']	= '</li>';
		$config['cur_tag_open'] 	= '<li class="active"><a>';
		$config['cur_tag_close'] 	= '</a></li>';
		$config['next_tag_open'] 	= '<li>';
		$config['next_tag_close'] 	= '</li>';
		$config['prev_tag_open'] 	= '<li>';
		$config['prev_tag_close'] 	= '</li>';
		$config['first_tag_open'] 	= '<li>';
		$config['first_tag_close'] 	= '</li>';
		$config['last_tag_open'] 	= '<li>';
		$config['last_tag_close'] 	= '</li>';
		$config['full_tag_close'] 	= '</ul></div>';

		$this->pagination->initialize($config);

		$data = array(
			'paginasi' =>$this->pagination->create_links(),
			'berita'   => $this->m_home->berita($limit,$start),
			'banner' => $this->m_home->home_banner(),
			'populer_berita' => $this->m_home->populer_berita(),
			'terbaru_berita' => $this->m_home->terbaru_berita(),
			'kategori' => $this->m_home->kategori(),
			'title' => 'ARTIKEL',
			'isi' => 'v_berita'
		);

		$this->load->view('layout/v_wrapper',$data,FALSE);
		
	}

	public function detail_artikel($slug_berita)
	{
		$berita = $this->m_home->detail_artikel($slug_berita);
		$data = array(
			'title' => $berita->judul_berita,
			'berita' => $this->m_home->detail_artikel($slug_berita),
			'banner' => $this->m_home->home_banner(),
			'populer_berita' => $this->m_home->populer_berita(),
			'terbaru_berita' => $this->m_home->terbaru_berita(),
			'kategori' => $this->m_home->kategori(),
			'isi' => 'v_detail_berita'
		);

		$this->load->view('layout/v_wrapperberita',$data,FALSE);
	}

	public function kategori($id_kategori)
	{
		$kategori = $this->m_home->kategoriberita($id_kategori);
		$data = array(
			'title' => 'Kategori artikel : ' .$kategori->nama_kategori,
			'berita' => $this->m_home->allberita($id_kategori),
			'banner' => $this->m_home->home_banner(),
			'populer_berita' => $this->m_home->populer_berita(),
			'terbaru_berita' => $this->m_home->terbaru_berita(),
			'kategori' => $this->m_home->kategori(),
			'isi' => 'v_kategoriberita'
		);

		$this->load->view('layout/v_wrapper',$data,FALSE);
	}

	public function banner()
	{
		$data = array(
			'title' => ' Banner',
			'title2' => 'Banner',
			'banner' => $this->m_banner->banner(),
			'isi' => 'v_detail_berita'
		);

		$this->load->view('layout/v_wrapper',$data,FALSE);
	}





}

/* End of file Controllername.php */
