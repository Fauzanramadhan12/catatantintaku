<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Profil_admin extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('m_profil');
	}
	

	public function index()
	{
		$data = array(
			'title' => 'PROFIL ADMIN',
			'profil' => $this->m_profil->profil(),
			'isi' => 'admin/profil/v_isi'
		);

		$this->load->view('admin/layout/v_wrapper',$data,FALSE);
	}

	public function detail($id_admin)
	{
		$data = array(
			'title' => 'DETAIL PROFIL',
            'profil' => $this->m_profil->allDataadmin($id_admin),
            'isi'    => 'admin/profil/v_detail'
		);

		$this->load->view('admin/layout/v_wrapper',$data,FALSE);
	}

	public function edit($id_admin)
	{

		$this->form_validation->set_rules('nama_admin', 'Nama Admin', 'required', array('required' => '%s Harus Diisi'));
		$this->form_validation->set_rules('username', 'Username', 'required', array('required' => '%s Harus Diisi'));
		$this->form_validation->set_rules('password', 'Password', 'required', array('required' => '%s Harus Diisi'));
		
		if ($this->form_validation->run() == TRUE) {
			$config['upload_path'] = './foto_admin/';
			$config['allowed_types']        = 'gif|jpg|png|jpeg';
			$config['max_size']             = 5000;
			$this->upload->initialize($config);
				if (!$this->upload->do_upload('foto_admin'))
                {

						$data = array(
							'title' => 'EDIT PROFIL',
							'error' => $this->upload->display_errors(),
							'profil' => $this->m_profil->detail($id_admin),
							'isi' => 'admin/profil/v_edit'
						);
				
						$this->load->view('admin/layout/v_wrapper',$data,FALSE);
                }
                else
                {
                        $upload_data 				= array('uploads' => $this->upload->data());
						$config['image_liblary']	= 'gd2';
						$config['source_image']		= './foto_admin/' .$upload_data['uploads']['file_name'];
						$this->load->library('image_lib', $config);
						// menghapus poto lama
						$profil = $this->m_profil->detail($id_admin);
						if ($profil->foto_admin !=="") {
							unlink('./foto_admin/' .$profil->foto_admin);
						}
						//end menghapus poto

						$data = array(
							'id_admin' => $id_admin,
							'nama_admin' => $this->input->post('nama_admin'), 
							'username' => $this->input->post('username'), 
							'password' => $this->input->post('password'), 
							'foto_admin' => $upload_data['uploads']['file_name'], 
						);

					$this->m_profil->edit($data);
					$this->session->set_flashdata('pesan', 'Profil Admin Berhasil Di Edit');
					redirect('profil_admin');
                }
					$upload_data 				= array('uploads' => $this->upload->data());
						$config['image_liblary']	= 'gd2';
						$config['source_image']		= './foto_admin/' .$upload_data['uploads']['file_name'];
						$this->load->library('image_lib', $config);

						$data = array(
							'id_admin' => $id_admin,
							'nama_admin' => $this->input->post('nama_admin'), 
							'username' => $this->input->post('username'), 
							'password' => $this->input->post('password'), 
						);

					$this->m_profil->edit($data);
					$this->session->set_flashdata('pesan', 'Profil Admin Berhasil Di Edit');
					redirect('profil_admin');
		}

		$data = array(
			'title' => 'EDIT PROFIL',
			'profil' => $this->m_profil->detail($id_admin),
			'isi' => 'admin/profil/v_edit'
		);

		$this->load->view('admin/layout/v_wrapper',$data,FALSE);
	}

}

/* End of file Controllername.php */
