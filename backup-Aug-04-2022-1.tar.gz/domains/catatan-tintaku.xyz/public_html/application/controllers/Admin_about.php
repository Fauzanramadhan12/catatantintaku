<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin_about extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('m_about');
	}
	

	public function index()
	{
		$data = array(
			'title' => 'ABOUT',
			'about' => $this->m_about->about(),
			'isi' => 'admin/about/v_isi'
		);

		$this->load->view('admin/layout/v_wrapper',$data,FALSE);
	}

	public function edit($id_about)
	{

		$this->form_validation->set_rules('isi', 'Isi', 'required', array('required' => '%s Harus Diisi'));
		
		if ($this->form_validation->run() == TRUE) {
			$config['upload_path'] = './foto_about/';
			$config['allowed_types']        = 'gif|jpg|png';
			$config['max_size']             = 5000;
			$this->upload->initialize($config);
				if (!$this->upload->do_upload('foto_about'))
                {

						$data = array(
							'title' => 'EDIT about',
							'error' => $this->upload->display_errors(),
							'about' => $this->m_about->detail($id_about),
							'isi' => 'admin/about/v_edit'
						);
				
						$this->load->view('admin/layout/v_wrapper',$data,FALSE);
                }
                else
                {
                        $upload_data 				= array('uploads' => $this->upload->data());
						$config['image_liblary']	= 'gd2';
						$config['source_image']		= './foto_about/' .$upload_data['uploads']['file_name'];
						$this->load->library('image_lib', $config);
						// menghapus poto lama
						$about = $this->m_about->detail($id_about);
						if ($about->foto_about !=="") {
							unlink('./foto_about/' .$about->foto_about);
						}
						//end menghapus poto

						$data = array(
							'id_about' => $id_about,
							'isi' => $this->input->post('isi'), 
							'foto_about' => $upload_data['uploads']['file_name'], 
						);

					$this->m_about->edit($data);
					$this->session->set_flashdata('pesan', 'about Berhasil Diedit');
					redirect('admin_about');
                }
					$upload_data 				= array('uploads' => $this->upload->data());
						$config['image_liblary']	= 'gd2';
						$config['source_image']		= './foto_about/' .$upload_data['uploads']['file_name'];
						$this->load->library('image_lib', $config);

						$data = array(
							'id_about' => $id_about,
							'isi' => $this->input->post('isi'), 
						);

					$this->m_about->edit($data);
					$this->session->set_flashdata('pesan', 'about Berhasil Diedit');
					redirect('admin_about');
		}

		$data = array(
			'title' => 'EDIT ABOUT',
			'about' => $this->m_about->detail($id_about),
			'isi' => 'admin/about/v_edit'
		);

		$this->load->view('admin/layout/v_wrapper',$data,FALSE);
	}

}

/* End of file Controllername.php */
