<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Profil_user extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('m_profiluser');
	}
	

	public function index()
	{
		$data = array(
			'title' => 'PROFIL USER',
			'profil' => $this->m_profiluser->profil(),
			'isi' => 'user/profil/v_isi'
		);

		$this->load->view('user/layout/v_wrapper',$data,FALSE);
	}

	public function detail($id_user)
	{
		$data = array(
			'title' => 'DETAIL PROFIL',
            'profil' => $this->m_profiluser->allDatauser($id_user),
            'isi'    => 'user/profil/v_detail'
		);

		$this->load->view('user/layout/v_wrapper',$data,FALSE);
	}

	public function edit($id_user)
	{

		$this->form_validation->set_rules('nama_user', 'Nama user', 'required', array('required' => '%s Harus Diisi'));
		$this->form_validation->set_rules('username', 'Username', 'required', array('required' => '%s Harus Diisi'));
		$this->form_validation->set_rules('password', 'Password', 'required', array('required' => '%s Harus Diisi'));
		
		if ($this->form_validation->run() == TRUE) {
			$config['upload_path'] = './foto_user/';
			$config['allowed_types']        = 'gif|jpg|png|jpeg';
			$config['max_size']             = 5000;
			$this->upload->initialize($config);
				if (!$this->upload->do_upload('foto_user'))
                {

						$data = array(
							'title' => 'EDIT PROFIL',
							'error' => $this->upload->display_errors(),
							'profil' => $this->m_profiluser->detail($id_user),
							'isi' => 'user/profil/v_edit'
						);
				
						$this->load->view('user/layout/v_wrapper',$data,FALSE);
                }
                else
                {
                        $upload_data 				= array('uploads' => $this->upload->data());
						$config['image_liblary']	= 'gd2';
						$config['source_image']		= './foto_user/' .$upload_data['uploads']['file_name'];
						$this->load->library('image_lib', $config);
						// menghapus poto lama
						$profil = $this->m_profiluser->detail($id_user);
						if ($profil->foto_user !=="") {
							unlink('./foto_user/' .$profil->foto_user);
						}
						//end menghapus poto

						$data = array(
							'id_user' => $id_user,
							'nama_user' => $this->input->post('nama_user'), 
							'username' => $this->input->post('username'), 
							'password' => $this->input->post('password'), 
							'foto_user' => $upload_data['uploads']['file_name'], 
						);

					$this->m_profiluser->edit($data);
					$this->session->set_flashdata('pesan', 'Profil user Berhasil Di Edit');
					redirect('profil_user');
                }
					$upload_data 				= array('uploads' => $this->upload->data());
						$config['image_liblary']	= 'gd2';
						$config['source_image']		= './foto_user/' .$upload_data['uploads']['file_name'];
						$this->load->library('image_lib', $config);

						$data = array(
							'id_user' => $id_user,
							'nama_user' => $this->input->post('nama_user'), 
							'username' => $this->input->post('username'), 
							'password' => $this->input->post('password'), 
						);

					$this->m_profiluser->edit($data);
					$this->session->set_flashdata('pesan', 'Profil user Berhasil Di Edit');
					redirect('profil_user');
		}

		$data = array(
			'title' => 'EDIT PROFIL',
			'profil' => $this->m_profiluser->detail($id_user),
			'isi' => 'user/profil/v_edit'
		);

		$this->load->view('user/layout/v_wrapper',$data,FALSE);
	}

}

/* End of file Controllername.php */
