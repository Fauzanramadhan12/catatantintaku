<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Contact extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('m_home');
	}

	public function index()
	{
		$data = array(
			'title' => 'CONTACT',
			'contact' => $this->m_home->contact(),
			'populer_berita' => $this->m_home->populer_berita(),
			'isi'	=> 'v_contact' 
		);
		$this->load->view('layout/v_wrapper', $data, FALSE);
	}
}

/* End of file Controllername.php */
