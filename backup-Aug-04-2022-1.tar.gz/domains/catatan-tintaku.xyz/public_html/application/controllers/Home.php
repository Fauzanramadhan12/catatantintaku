<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('m_home');
	}

	public function index()
	{
		$data = array(
			'title' => 'Home',
			'berita_slider' => $this->m_home->slider_berita(),
			'home_berita' => $this->m_home->home_berita(),
			'populer_berita' => $this->m_home->populer_berita(),
			'terbaru_berita' => $this->m_home->terbaru_berita(),
			'banner' => $this->m_home->home_banner(),
			'kategori' => $this->m_home->kategori(),
			'isi'	=> 'v_home'
		);
		$this->load->view('layout/v_wrapper', $data, FALSE);
		
	}

}

/* End of file Controllername.php */
