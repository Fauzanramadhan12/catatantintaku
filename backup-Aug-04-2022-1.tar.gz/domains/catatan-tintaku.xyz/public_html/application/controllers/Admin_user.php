<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Admin_user extends CI_Controller {

	
	public function __construct()
	{
		parent::__construct();
     	$this->load->model('m_user');
	}
	

	public function index()
	{
		$data = array(
			'title' => 'DATA USER',
			'user' => $this->m_user->list(),
			'isi' => 'admin/user/v_list'
		);

		$this->load->view('admin/layout/v_wrapper',$data,FALSE);
	}

	public function detail($id_user)
	{
		$data = array(
			'title' => 'DETAIL USER',
            'user' => $this->m_user->allDatauser($id_user),
            'isi'    => 'admin/user/v_detail'
		);

		$this->load->view('admin/layout/v_wrapper',$data,FALSE);
	}

	public function add()
	{

		$this->form_validation->set_rules('nama_user', 'Nama User','required', array('required' => '%s Harus Diisi'));
		$this->form_validation->set_rules('username', 'username', 'required', array('required' => '%s Harus Diisi'));
		$this->form_validation->set_rules('password', 'password', 'required', array('required' => '%s Harus Diisi'));
		
		if ($this->form_validation->run() == TRUE) {
			$config['upload_path'] = './foto_user/';
			$config['allowed_types']        = 'gif|jpg|png';
			$config['max_size']             = 5000;
			$this->upload->initialize($config);
				if (!$this->upload->do_upload('foto_user'))
                {

						$data = array(
							'title' => 'TAMBAH USER',
							'error' => $this->upload->display_errors(),
							'isi' => 'admin/user/v_add'
						);
				
						$this->load->view('admin/layout/v_wrapper',$data,FALSE);
                }
                else
                {
                        $upload_data 				= array('uploads' => $this->upload->data());
						$config['image_liblary']	= 'gd2';
						$config['source_image']		= './foto_user/' .$upload_data['uploads']['file_name'];
						$this->load->library('image_lib', $config);

						$data = array(
							'nama_user' => $this->input->post('nama_user'), 
							'username' => $this->input->post('username'), 
							'password' => $this->input->post('password'), 
							'foto_user' => $upload_data['uploads']['file_name'], 
						);

					$this->m_user->add($data);
					$this->session->set_flashdata('pesan', 'User Berhasil Ditambahkan');
					redirect('admin_user');
					
					
                }
		}

		$data = array(
			'title' => 'TAMBAH USER',
			'isi' => 'admin/user/v_add'
		);

		$this->load->view('admin/layout/v_wrapper',$data,FALSE);

	}

	public function edit($id_user)
	{

		$this->form_validation->set_rules('nama_user', 'Nama User', 'required', array('required' => '%s Harus Diisi'));
		$this->form_validation->set_rules('username', 'username', 'required', array('required' => '%s Harus Diisi'));
		$this->form_validation->set_rules('password', 'password', 'required', array('required' => '%s Harus Diisi'));
		
		if ($this->form_validation->run() == TRUE) {
			$config['upload_path'] = './foto_user/';
			$config['allowed_types']        = 'gif|jpg|png';
			$config['max_size']             = 5000;
			$this->upload->initialize($config);
				if (!$this->upload->do_upload('foto_user'))
                {

						$data = array(
							'title' => 'EDIT USER',
							'error' => $this->upload->display_errors(),
							'user' => $this->m_user->detail($id_user),
							'isi' => 'admin/user/v_edit'
						);
				
						$this->load->view('admin/layout/v_wrapper',$data,FALSE);
                }
                else
                {
                        $upload_data 				= array('uploads' => $this->upload->data());
						$config['image_liblary']	= 'gd2';
						$config['source_image']		= './foto_user/' .$upload_data['uploads']['file_name'];
						$this->load->library('image_lib', $config);
						// menghapus poto lama
						$user = $this->m_user->detail($id_user);
						if ($user->foto_user !=="") {
							unlink('./foto_user/' .$user->foto_user);
						}
						//end menghapus poto

						$data = array(
							'id_user' => $id_user,
							'nama_user' => $this->input->post('nama_user'), 
							'username' => $this->input->post('username'), 
							'password' => $this->input->post('password'), 
							'foto_user' => $upload_data['uploads']['file_name'], 
						);

					$this->m_user->edit($data);
					$this->session->set_flashdata('pesan', 'data berhasil diedit');
					redirect('admin_user');
                }
					$upload_data 				= array('uploads' => $this->upload->data());
						$config['image_liblary']	= 'gd2';
						$config['source_image']		= './foto_user/' .$upload_data['uploads']['file_name'];
						$this->load->library('image_lib', $config);

						$data = array(
							'id_user' => $id_user,
							'nama_user' => $this->input->post('nama_user'), 
							'username' => $this->input->post('username'), 
							'password' => $this->input->post('password'),
						);

					$this->m_user->edit($data);
					$this->session->set_flashdata('pesan', 'User Berhasil Diedit');
					redirect('admin_user');
		}

		$data = array(
			'title' => 'EDIT USER',
			'user' => $this->m_user->detail($id_user),
			'isi' => 'admin/user/v_edit'
		);

		$this->load->view('admin/layout/v_wrapper',$data,FALSE);
	}

	public function delete($id_user)
	{
		// menghapus poto lama
		$user = $this->m_user->detail($id_user);
		if ($user->foto_user !=="") {
			unlink('./foto_user/' .$user->foto_user);
		}
		//end menghapus poto

		$data = array('id_user' => $id_user );

		$this->m_user->delete($data);
		$this->session->set_flashdata('pesan', 'User Berhasil Di Hapus');
		redirect('admin_user');
	}
}

/* End of file Controllername.php */
