<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {

	public function index()
	{
		
		$this->form_validation->set_rules('username', 'username', 'required');
		$this->form_validation->set_rules('password', 'password', 'required');
		
		if ($this->form_validation->run() == TRUE) {
			$username = $this->input->post('username');
			$password = $this->input->post('password');
			$this->admin_login->Login($username,$password);

		}

		$data = array('title' => 'Login');
		$this->load->view('v_login',$data,FALSE);
	}

	public function logout()
	{
		$this->admin_login->logout();
	}

}

/* End of file Controllername.php */
