<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class Administrator extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('m_admin');
		$this->load->model('m_contact');
	}

	public function index()
	{
		$data = array(
			'title' => 'Administrator',
			'total_berita' => $this->m_admin->total_berita(),
			'total_user' => $this->m_admin->total_user(),
			'contact' => $this->m_contact->contact(),
			'isi'	=> 'admin/v_home'
		);
		$this->load->view('admin/layout/v_wrapper', $data, FALSE);
	}

}

/* End of file Controllername.php */
