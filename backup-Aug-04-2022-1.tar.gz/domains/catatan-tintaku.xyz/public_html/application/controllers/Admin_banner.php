<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin_banner extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('m_banner');
	}
	

	public function index()
	{
		$data = array(
			'title' => 'Banner',
			'banner' => $this->m_banner->banner(),
			'isi' => 'admin/baner/v_isi'
		);

		$this->load->view('admin/layout/v_wrapper',$data,FALSE);
	}

	public function add()
	{
		$this->form_validation->set_rules('keterangan', 'keterangan', 'required', array('required' => '%s Harus Diisi'));
		
		
		if ($this->form_validation->run() == TRUE) {
			$config['upload_path'] = './foto_banner/';
			$config['allowed_types']        = 'gif|jpg|png|jepg';
			$config['max_size']             = 5000;
			$this->upload->initialize($config);
				if (!$this->upload->do_upload('foto_banner'))
                {

						$data = array(
							'title' => 'TAMBAH BANNER',
							'error' => $this->upload->display_errors(),
							'isi' => 'admin/baner/v_add'
						);
				
						$this->load->view('admin/layout/v_wrapper',$data,FALSE);
                }
                else
                {
                        $upload_data 				= array('uploads' => $this->upload->data());
						$config['image_liblary']	= 'gd2';
						$config['source_image']		= './foto_banner/' .$upload_data['uploads']['file_name'];
						$this->load->library('image_lib', $config);

						$data = array(
							'keterangan' => $this->input->post('keterangan'), 
							'foto_banner' => $upload_data['uploads']['file_name'], 
						);

					$this->m_banner->add($data);
					$this->session->set_flashdata('pesan', 'Banner Berhasil Ditambahkan');
					redirect('admin_banner');

                }
		}

		$data = array(
			'title' => 'TAMBAH BANNER',
			'isi' => 'admin/baner/v_add'
		);

		$this->load->view('admin/layout/v_wrapper',$data,FALSE);

	}

	public function edit($id_banner)
	{

		$this->form_validation->set_rules('keterangan', 'Keterangan', 'required', array('required' => '%s Harus Diisi'));
		
		if ($this->form_validation->run() == TRUE) {
			$config['upload_path'] = './foto_banner/';
			$config['allowed_types']        = 'gif|jpg|png';
			$config['max_size']             = 5000;
			$this->upload->initialize($config);
				if (!$this->upload->do_upload('foto_banner'))
                {

						$data = array(
							'title' => 'EDIT BANNER',
							'error' => $this->upload->display_errors(),
							'banner' => $this->m_banner->detail($id_banner),
							'isi' => 'admin/baner/v_edit'
						);
				
						$this->load->view('admin/layout/v_wrapper',$data,FALSE);
                }
                else
                {
                        $upload_data 				= array('uploads' => $this->upload->data());
						$config['image_liblary']	= 'gd2';
						$config['source_image']		= './foto_banner/' .$upload_data['uploads']['file_name'];
						$this->load->library('image_lib', $config);
						// menghapus poto lama
						$banner = $this->m_banner->detail($id_banner);
						if ($banner->foto_banner !=="") {
							unlink('./foto_banner/' .$banner->foto_banner);
						}
						//end menghapus poto

						$data = array(
							'id_banner' => $id_banner,
							'keterangan' => $this->input->post('keterangan'), 
							'foto_banner' => $upload_data['uploads']['file_name'], 
						);

					$this->m_banner->edit($data);
					$this->session->set_flashdata('pesan', 'Banner Berhasil Diedit');
					redirect('admin_banner');
                }
					$upload_data 				= array('uploads' => $this->upload->data());
						$config['image_liblary']	= 'gd2';
						$config['source_image']		= './foto_banner/' .$upload_data['uploads']['file_name'];
						$this->load->library('image_lib', $config);

						$data = array(
							'id_banner' => $id_banner,
							'keterangan' => $this->input->post('keterangan'), 
						);

					$this->m_banner->edit($data);
					$this->session->set_flashdata('pesan', 'Banner Berhasil Diedit');
					redirect('admin_banner');
		}

		$data = array(
			'title' => 'EDIT BANNER',
			'banner' => $this->m_banner->detail($id_banner),
			'isi' => 'admin/baner/v_edit'
		);

		$this->load->view('admin/layout/v_wrapper',$data,FALSE);
	}

	public function delete($id_banner)
	{
		// menghapus poto lama
		$banner = $this->m_banner->detail($id_banner);
		if ($banner->foto_banner !=="") {
			unlink('./foto_banner/' .$banner->foto_banner);
		}
		//end menghapus poto

		$data = array('id_banner' => $id_banner );

		$this->m_banner->delete($data);
		$this->session->set_flashdata('pesan', 'Banner Berhasil Di Hapus');
		redirect('admin_banner');
	}

}

/* End of file Controllername.php */
