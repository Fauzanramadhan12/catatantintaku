<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class About extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('m_home');
	}

	public function index()
	{
		$data = array(
			'title' => 'ABOUT US',
			'about' => $this->m_home->about(),
			'populer_berita' => $this->m_home->populer_berita(),
			'isi'	=> 'v_about' 
		);
		$this->load->view('layout/v_wrapper', $data, FALSE);
	}
}

/* End of file Controllername.php */
