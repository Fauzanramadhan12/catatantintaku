<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('m_userlogin');
		
		//Do your magic here
	}

	public function index()
	{
		$data = array(
			'title' => 'USER',
			'total_berita' =>$this->m_userlogin->total_berita(),
			'isi'	=> 'user/v_home'
		);
		$this->load->view('user/layout/v_wrapper', $data, FALSE);
	}

}

/* End of file Controllername.php */
