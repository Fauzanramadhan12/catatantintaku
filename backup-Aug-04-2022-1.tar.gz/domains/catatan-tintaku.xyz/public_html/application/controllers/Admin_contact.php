<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin_contact extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('m_contact');
	}

	public function index()
	{
		$data = array(
			'title' => 'CONTACT',
			'contact' => $this->m_contact->contact(),
			'isi' => 'admin/contact/v_isi'
		);
		$this->load->view('admin/layout/v_wrapper',$data,FALSE);
	}

	public function detail($id_contact)
	{
		$data = array(
			'title' => 'DETAIL CONTACT',
            'contact' => $this->m_contact->allDatacontact($id_contact),
            'isi'    => 'admin/contact/v_detail'
		);
		$this->load->view('admin/layout/v_wrapper',$data,FALSE);
	}

	public function add()
	{
		$data = array(
			'nama' => $this->input->post('nama'),
			'email' => $this->input->post('email'),
			'subjek' => $this->input->post('subjek'),
			'isi' => $this->input->post('isi'),
		);
		$this->m_contact->add($data);
		$this->session->set_flashdata('pesan', 'contactan Berhasil Dikirim');
		redirect('contact');
	}

}
