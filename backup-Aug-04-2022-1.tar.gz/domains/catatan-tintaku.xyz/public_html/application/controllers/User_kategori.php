<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User_kategori extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('m_kategori');
	}
	

	public function index()
	{
		$data = array(
			'title' => 'KATEGORI',
			'kategori' => $this->m_kategori->kategori(),
			'isi' => 'user/kategori/v_isi'
		);

		$this->load->view('user/layout/v_wrappermodal',$data,FALSE);
	}

	public function add()
	{
		$data = array(
			'nama_kategori' => $this->input->post('nama_kategori')
		);
		$this->m_kategori->add($data);
		$this->session->set_flashdata('pesan', 'Kategori Berhasil Ditambahkan');

		redirect('user_kategori');
	}

	public function edit($id_kategori)
	{
		$data = array(
			'id_kategori' => $id_kategori,
			'nama_kategori' => $this->input->post('nama_kategori')
		);
		$this->m_kategori->edit($data);
		$this->session->set_flashdata('pesan', 'Kategori Berhasil Diedit');

		redirect('user_kategori');
	}

	public function delete($id_kategori)
	{
		$data = array(
			'id_kategori' => $id_kategori,
		);
		$this->m_kategori->delete($data);
		$this->session->set_flashdata('pesan', 'Kategori Berhasil Dihapus');

		redirect('user_kategori');
	}

}

/* End of file Controllername.php */
