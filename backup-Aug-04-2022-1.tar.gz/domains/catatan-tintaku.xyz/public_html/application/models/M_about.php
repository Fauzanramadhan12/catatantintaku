<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_about extends CI_Model {

	public function about()
	{
		$this->db->select('*');
		$this->db->from('tbl_about');
		$this->db->order_by('id_about','ASC');
		return $this->db->get()->result();
	}

	public function detail($id_about)
	{
		$this->db->select('*');
		$this->db->from('tbl_about');
		$this->db->where('id_about', $id_about);
		return $this->db->get()->row();
	}

	public function edit($data)
	{
		$this->db->where('id_about', $data['id_about']);
		$this->db->update('tbl_about', $data);
	}
}

/* End of file ModelName.php */
