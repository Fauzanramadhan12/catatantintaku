<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_home extends CI_Model {

	public function about()
	{
		$this->db->select('*');
		$this->db->from('tbl_about');
		$this->db->order_by('id_about','1');
		return $this->db->get()->result();
	}

	public function contact()
	{
		$this->db->select('*');
		$this->db->from('tbl_contact');
		$this->db->order_by('id_contact','DESC');
		return $this->db->get()->result();
	}

	public function kategori()
	{
		$this->db->select('*');
		$this->db->from('tbl_kategori');
		$this->db->order_by('id_kategori','DESC');
		return $this->db->get()->result();
	}

	public function slider_berita()
	{
		$this->db->select('*');
		$this->db->from('tbl_berita');
		$this->db->join('tbl_admin', 'tbl_admin.id_admin = tbl_berita.id_admin', 'left');
		$this->db->join('tbl_user', 'tbl_user.id_user = tbl_berita.id_user', 'left');
		$this->db->join('tbl_kategori', 'tbl_kategori.id_kategori = tbl_berita.id_kategori', 'left');	
		$this->db->order_by('id_berita','DESC');
		$this->db->limit(5);
		return $this->db->get()->result();
	}

	public function home_berita()
	{
		$this->db->select('*');
		$this->db->from('tbl_berita');
		$this->db->join('tbl_admin', 'tbl_admin.id_admin = tbl_berita.id_admin', 'left');
		$this->db->join('tbl_user', 'tbl_user.id_user = tbl_berita.id_user', 'left');
		$this->db->join('tbl_kategori', 'tbl_kategori.id_kategori = tbl_berita.id_kategori', 'left');	
		$this->db->order_by('id_berita','DESC');
		$this->db->limit(7);
		return $this->db->get()->result();
	}

	public function terbaru_berita()
	{
		$this->db->select('*');
		$this->db->from('tbl_berita');
		$this->db->join('tbl_admin', 'tbl_admin.id_admin = tbl_berita.id_admin', 'left');
		$this->db->join('tbl_user', 'tbl_user.id_user = tbl_berita.id_user', 'left');
		$this->db->join('tbl_kategori', 'tbl_kategori.id_kategori = tbl_berita.id_kategori', 'left');	
		$this->db->order_by('id_berita','DESC');
		$this->db->limit(4);
		return $this->db->get()->result();
	}

	public function populer_berita()
	{
		$this->db->select('*');
		$this->db->from('tbl_berita');
		$this->db->join('tbl_admin', 'tbl_admin.id_admin = tbl_berita.id_admin', 'left');
		$this->db->join('tbl_user', 'tbl_user.id_user = tbl_berita.id_user', 'left');
		$this->db->join('tbl_kategori', 'tbl_kategori.id_kategori = tbl_berita.id_kategori', 'left');	
		$this->db->order_by('total_views','DESC');
		$this->db->limit(4);
		return $this->db->get()->result();
	}

	public function home_banner()
	{
		$this->db->select('*');
		$this->db->from('tbl_banner');
		$this->db->order_by('id_banner','DESC');
		return $this->db->get()->result();
	}
	public function berita($limit,$start)
	{
		$this->db->select('*');
		$this->db->from('tbl_berita');
		$this->db->join('tbl_admin', 'tbl_admin.id_admin = tbl_berita.id_admin', 'left');
		$this->db->join('tbl_user', 'tbl_user.id_user = tbl_berita.id_user', 'left');
		$this->db->join('tbl_kategori', 'tbl_kategori.id_kategori = tbl_berita.id_kategori', 'left');	
		$this->db->order_by('id_berita','desc');
		$this->db->limit($limit,$start);
		return $this->db->get()->result();
	}

	public function total_berita()
	{
		$this->db->select('*');
		$this->db->from('tbl_berita');
		$this->db->join('tbl_admin', 'tbl_admin.id_admin = tbl_berita.id_admin', 'left');
		$this->db->join('tbl_user', 'tbl_user.id_user = tbl_berita.id_user', 'left');
		$this->db->order_by('id_berita','DESC');
		return $this->db->get()->result();
	}

	public function detail_artikel($slug_berita)
	{
		$this->db->select('*');
		$this->db->from('tbl_berita');
		$this->db->join('tbl_admin', 'tbl_admin.id_admin = tbl_berita.id_admin', 'left');
		$this->db->join('tbl_user', 'tbl_user.id_user = tbl_berita.id_user', 'left');
		$this->db->join('tbl_kategori', 'tbl_kategori.id_kategori = tbl_berita.id_kategori', 'left');	
		$this->db->where('slug_berita', $slug_berita );
		return $this->db->get()->row();
	}

	public function allberita($id_kategori)
	{
		$this->db->select('*');
		$this->db->from('tbl_berita');
		$this->db->join('tbl_admin', 'tbl_admin.id_admin = tbl_berita.id_admin', 'left');
		$this->db->join('tbl_user', 'tbl_user.id_user = tbl_berita.id_user', 'left');
		$this->db->join('tbl_kategori', 'tbl_kategori.id_kategori = tbl_berita.id_kategori', 'left');	
		$this->db->where('tbl_berita.id_kategori', $id_kategori);
		$this->db->order_by('tbl_berita.id_kategori', 'DESC');
		return $this->db->get()->result();
	}

	public function kategoriberita($id_kategori)
	{
		$this->db->select('*');
		$this->db->from('tbl_kategori');
		$this->db->where('id_kategori', $id_kategori);
		$this->db->order_by('id_kategori','DESC');
		return $this->db->get()->row();
	}


}

/* End of file ModelName.php */
