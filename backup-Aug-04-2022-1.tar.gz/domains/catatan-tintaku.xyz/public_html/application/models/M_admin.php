<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class M_admin extends CI_Model {

	public function total_berita()
	{
		return $this->db->get('tbl_berita')->num_rows();
	}

	public function total_user()
	{
		return $this->db->get('tbl_user')->num_rows();
	}

	// public function total_sertifikat()
	// {
	// 	return $this->db->get('tbl_user')->num_rows();
	// }

}

/* End of file ModelName.php */
