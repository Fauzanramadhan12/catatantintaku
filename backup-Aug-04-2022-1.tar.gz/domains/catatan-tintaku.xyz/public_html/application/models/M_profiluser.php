<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class M_profiluser extends CI_Model {

	public function profil()
	{
		$this->db->where('id_user',$this->session->userdata('id_user'));
		return $this->db->get('tbl_user')->result();
	}

	public function detail($id_user)
	{
		$this->db->select('*');
		$this->db->from('tbl_user');
		$this->db->where('id_user', $id_user);
		return $this->db->get()->row();
	}

	public function allDatauser($id_user)
    {

		$this->db->select("*");
    	$this->db->where("id_user",$id_user);
    	return $this->db->get('tbl_user')->result();
    }

	public function edit($data)
	{
		
		$this->db->where('id_user', $data['id_user']);
		$this->db->update('tbl_user', $data);

	}

}

/* End of file ModelName.php */
