<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class M_profil extends CI_Model {

	public function profil()
	{
		$this->db->select('*');
		$this->db->from('tbl_admin');
		$this->db->order_by('id_admin','ASC');
		return $this->db->get()->result();
	}

	public function detail($id_admin)
	{
		$this->db->select('*');
		$this->db->from('tbl_admin');
		$this->db->where('id_admin', $id_admin);
		return $this->db->get()->row();
	}

	public function allDataadmin($id_admin)
    {

		$this->db->select("*");
    	$this->db->where("id_admin",$id_admin);
    	return $this->db->get('tbl_admin')->result();
    }

	public function edit($data)
	{
		
		$this->db->where('id_admin', $data['id_admin']);
		$this->db->update('tbl_admin', $data);

	}

}

/* End of file ModelName.php */
