<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_contact extends CI_Model {

	public function contact()
	{
		$this->db->select('*');
		$this->db->from('tbl_contact');
		$this->db->order_by('id_contact','DESC');
		return $this->db->get()->result();
	}

	public function add($data)
	{
		$this->db->insert('tbl_contact', $data);
	}

	public function detail($id_contact)
	{
		$this->db->select('*');
		$this->db->from('tbl_contact');
		$this->db->where('id_contact', $id_contact);
		return $this->db->get()->row();
	}

	public function edit($data)
	{
		$this->db->where('id_contact', $data['id_contact']);
		$this->db->update('tbl_contact', $data);
	}

	public function delete($data)
	{
		$this->db->where('id_contact', $data['id_contact']);
		$this->db->delete('tbl_contact', $data);
	}

	public function allDatacontact($id_contact)
    {

		$this->db->select("*");
    	$this->db->where("id_contact",$id_contact);
    	return $this->db->get('tbl_contact')->result();
    }

}

/* End of file ModelName.php */
