<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class M_userlogin extends CI_Model {

	public function total_berita()
	{
		$this->db->where('id_user',$this->session->userdata('id_user'));
		return $this->db->get('tbl_berita')->num_rows();
	}

}

/* End of file ModelName.php */
