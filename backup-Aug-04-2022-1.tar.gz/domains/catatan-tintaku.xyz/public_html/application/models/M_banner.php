<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_banner extends CI_Model {

	public function banner()
	{
		$this->db->select('*');
		$this->db->from('tbl_banner');
		$this->db->order_by('id_banner','ASC');
		return $this->db->get()->result();
	}

	public function add($data)
	{
		$this->db->insert('tbl_banner', $data);
	}

	public function detail($id_banner)
	{
		$this->db->select('*');
		$this->db->from('tbl_banner');
		$this->db->where('id_banner', $id_banner);
		return $this->db->get()->row();
	}

	public function edit($data)
	{
		$this->db->where('id_banner', $data['id_banner']);
		$this->db->update('tbl_banner', $data);
	}

	public function delete($data)
	{
		$this->db->where('id_banner', $data['id_banner']);
		$this->db->delete('tbl_banner', $data);
	}

}

/* End of file ModelName.php */
