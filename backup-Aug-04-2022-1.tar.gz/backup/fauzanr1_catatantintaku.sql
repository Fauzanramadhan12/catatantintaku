-- MySQL dump 10.19  Distrib 10.3.32-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: fauzanr1_catatantintaku
-- ------------------------------------------------------
-- Server version	10.3.32-MariaDB-cll-lve

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `page_views`
--

DROP TABLE IF EXISTS `page_views`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `page_views` (
  `page_id` int(11) unsigned NOT NULL,
  `visitor_ip` varchar(255) NOT NULL,
  KEY `page_id` (`page_id`),
  CONSTRAINT `page_views_ibfk_1` FOREIGN KEY (`page_id`) REFERENCES `tbl_berita` (`id_berita`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `page_views`
--

LOCK TABLES `page_views` WRITE;
/*!40000 ALTER TABLE `page_views` DISABLE KEYS */;
INSERT INTO `page_views` VALUES (11,'103.105.30.104'),(9,'103.105.30.104'),(12,'51.91.125.152'),(11,'51.91.125.152'),(10,'51.91.125.152'),(9,'51.91.125.152'),(12,'51.195.90.229'),(11,'51.195.90.229'),(10,'51.195.90.229'),(9,'51.195.90.229'),(12,'146.59.157.229'),(11,'146.59.157.229'),(10,'146.59.157.229'),(9,'146.59.157.229'),(12,'103.105.31.106'),(14,'103.105.31.127'),(14,'103.105.30.98'),(14,'103.105.31.66'),(12,'103.105.31.66'),(14,'175.196.127.111'),(9,'175.196.127.111'),(10,'175.196.127.111'),(11,'175.196.127.111'),(12,'175.196.127.111'),(12,'125.165.108.107'),(14,'103.105.30.70'),(12,'103.105.30.126'),(10,'54.36.148.235'),(11,'54.36.149.82'),(9,'54.36.148.228'),(12,'54.36.148.103'),(14,'54.36.148.191'),(9,'54.36.148.119'),(10,'54.36.148.119'),(11,'54.36.148.119'),(12,'54.36.148.119'),(10,'144.76.67.25'),(11,'144.76.67.25'),(9,'144.76.67.25'),(12,'144.76.67.25'),(14,'144.76.67.25'),(14,'54.36.148.108'),(12,'114.125.60.12'),(14,'103.105.30.86'),(12,'103.105.30.86'),(11,'140.213.149.56'),(10,'54.36.149.70'),(11,'54.36.148.59'),(9,'54.36.148.52'),(12,'54.36.148.198'),(14,'54.36.149.28'),(9,'54.36.148.11'),(10,'54.36.148.11'),(11,'54.36.148.11'),(12,'54.36.148.11'),(14,'54.36.148.143'),(12,'103.105.30.95'),(15,'103.105.31.66'),(15,'103.105.31.105'),(12,'103.105.31.105'),(15,'103.105.31.122'),(15,'54.36.148.29'),(14,'103.105.30.119'),(15,'103.105.30.119'),(12,'125.167.57.96'),(11,'103.105.30.119'),(12,'103.105.30.119'),(11,'112.215.245.31'),(15,'103.105.30.86'),(15,'182.4.71.80'),(15,'54.36.148.24'),(15,'103.105.31.119'),(15,'116.206.36.27'),(10,'116.206.36.27'),(10,'116.206.36.55'),(15,'114.125.46.203'),(12,'116.206.36.55'),(12,'114.125.29.143'),(15,'114.125.29.143'),(14,'114.5.146.41'),(15,'114.5.146.41'),(12,'114.5.146.41'),(15,'116.206.36.8'),(15,'149.154.161.3'),(14,'69.160.160.58'),(12,'69.160.160.58'),(15,'69.160.160.58'),(9,'69.160.160.58'),(10,'69.160.160.58'),(11,'69.160.160.58'),(10,'54.36.149.9'),(9,'54.36.149.90'),(12,'54.36.148.39'),(14,'54.36.148.125'),(9,'54.36.148.223'),(10,'54.36.148.223'),(11,'54.36.148.223'),(12,'54.36.148.223'),(11,'54.36.149.65'),(16,'180.242.192.98'),(14,'54.36.149.66'),(15,'54.36.149.66'),(10,'54.36.148.213'),(11,'54.36.148.55'),(16,'54.36.148.91'),(9,'54.36.149.65'),(12,'54.36.149.10'),(14,'54.36.149.107'),(9,'54.36.149.30'),(10,'54.36.149.30'),(11,'54.36.149.30'),(12,'54.36.149.30'),(16,'54.36.149.30'),(16,'180.242.198.216'),(16,'173.252.111.12'),(14,'54.36.148.58'),(15,'54.36.148.58'),(16,'54.36.148.20'),(15,'180.242.192.137'),(16,'180.242.192.137'),(15,'54.36.148.226'),(15,'54.36.148.16'),(14,'51.158.121.220'),(15,'51.158.121.220'),(9,'51.158.98.126'),(15,'51.158.119.246'),(14,'51.158.105.7'),(11,'51.15.196.150'),(10,'51.15.192.164'),(12,'51.15.202.195'),(9,'51.158.124.23'),(10,'51.158.124.23'),(11,'51.158.124.23'),(12,'51.158.124.23'),(16,'51.158.124.23'),(16,'51.158.113.13'),(16,'180.242.192.180'),(12,'180.242.192.180'),(10,'54.36.149.38'),(10,'54.36.148.183'),(9,'54.36.149.22'),(12,'54.36.148.38'),(11,'54.36.148.197'),(11,'54.36.148.103'),(14,'54.36.148.209'),(15,'54.36.148.209'),(14,'54.36.149.49'),(9,'54.36.149.86'),(10,'54.36.149.86'),(11,'54.36.149.86'),(12,'54.36.149.86'),(16,'54.36.149.86'),(9,'54.36.149.57'),(12,'54.36.148.106'),(14,'54.36.149.106'),(9,'54.36.148.231'),(10,'54.36.148.231'),(11,'54.36.148.231'),(12,'54.36.148.231'),(16,'54.36.148.231'),(14,'54.36.148.55'),(15,'54.36.148.55'),(16,'51.222.253.5'),(15,'51.222.253.9'),(16,'54.36.148.183'),(15,'54.36.148.101'),(16,'116.206.36.43'),(10,'54.36.148.42'),(11,'54.36.149.87'),(9,'54.36.148.25'),(12,'54.36.148.179'),(14,'54.36.148.104'),(9,'54.36.148.81'),(10,'54.36.148.81'),(11,'54.36.148.81'),(12,'54.36.148.81'),(16,'54.36.148.81'),(14,'54.36.149.12'),(15,'54.36.149.12'),(10,'51.222.253.15'),(9,'51.222.253.7'),(12,'51.222.253.5'),(11,'51.222.253.18'),(14,'51.222.253.17'),(15,'51.222.253.17'),(14,'51.222.253.13'),(9,'51.222.253.4'),(10,'51.222.253.4'),(11,'51.222.253.4'),(12,'51.222.253.4'),(16,'51.222.253.4'),(16,'54.36.149.59'),(15,'54.36.148.70'),(16,'51.222.253.8'),(15,'51.222.253.1');
/*!40000 ALTER TABLE `page_views` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_about`
--

DROP TABLE IF EXISTS `tbl_about`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_about` (
  `id_about` int(11) NOT NULL AUTO_INCREMENT,
  `isi` text DEFAULT NULL,
  `foto_about` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id_about`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_about`
--

LOCK TABLES `tbl_about` WRITE;
/*!40000 ALTER TABLE `tbl_about` DISABLE KEYS */;
INSERT INTO `tbl_about` VALUES (1,'<p>Catatan Tintaku</p>\r\n','catatan.png');
/*!40000 ALTER TABLE `tbl_about` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_admin`
--

DROP TABLE IF EXISTS `tbl_admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_admin` (
  `id_admin` int(11) NOT NULL AUTO_INCREMENT,
  `nama_admin` varchar(25) DEFAULT NULL,
  `username` varchar(25) DEFAULT NULL,
  `password` varchar(25) DEFAULT NULL,
  `foto_admin` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id_admin`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_admin`
--

LOCK TABLES `tbl_admin` WRITE;
/*!40000 ALTER TABLE `tbl_admin` DISABLE KEYS */;
INSERT INTO `tbl_admin` VALUES (1,'Fauzan Purma R','Fauzankece','Fauzan@12345','website.jpg');
/*!40000 ALTER TABLE `tbl_admin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_banner`
--

DROP TABLE IF EXISTS `tbl_banner`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_banner` (
  `id_banner` int(11) NOT NULL AUTO_INCREMENT,
  `keterangan` varchar(25) DEFAULT NULL,
  `foto_banner` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id_banner`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_banner`
--

LOCK TABLES `tbl_banner` WRITE;
/*!40000 ALTER TABLE `tbl_banner` DISABLE KEYS */;
INSERT INTO `tbl_banner` VALUES (1,'banner 1','bgg.jpg');
/*!40000 ALTER TABLE `tbl_banner` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_berita`
--

DROP TABLE IF EXISTS `tbl_berita`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_berita` (
  `id_berita` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `judul_berita` varchar(255) DEFAULT NULL,
  `isi_berita` text DEFAULT NULL,
  `foto_berita` varchar(255) DEFAULT NULL,
  `tgl_berita` date DEFAULT NULL,
  `id_kategori` int(11) DEFAULT NULL,
  `id_admin` int(11) DEFAULT NULL,
  `id_user` int(11) DEFAULT NULL,
  `slug_berita` varchar(255) DEFAULT NULL,
  `total_views` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id_berita`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_berita`
--

LOCK TABLES `tbl_berita` WRITE;
/*!40000 ALTER TABLE `tbl_berita` DISABLE KEYS */;
INSERT INTO `tbl_berita` VALUES (9,'Sebuah Definisi Cinta','<p>Cintaku dalam definisi yang sangat sederhana, tanpa alasan rumit, tanpa obsesi yang berlebihan, dan tanpa pengharapan yang terlalu banyak untuk diterima.</p>\r\n\r\n<p>aku akan mencintai dengan benar - benar tulus, pada satu orang dalam satu waktu, aku akan menjadi orang yang setia, karna tak mudah dalam membuat ku jatuh cinta.</p>\r\n\r\n<p>dalam berteman, tak mudah menemukan orang yang membuatku nyaman, apalagi dalam urusan cinta, aku akan sangat berhati - hati terhadap perasaan ku.</p>\r\n\r\n<p>aku mungkin terlihat orang yang penakut berkomitmen dengan cinta, padahal aku sebenarnya ingin mencintai satu orang seumur hidupku, ketika aku jatih cinta, au akan berharap dia adalah cinta terakhir yang kumiliki.....</p>\r\n','sebuah_definisi_cinta.jpg','2022-06-03',2,NULL,2,'sebuah-definisi-cinta',35),(10,'Alam','<p>Alam....</p>\r\n\r\n<p>izinkan aku mencintaimu secara sempurna, melihatmu secara nyata</p>\r\n\r\n<p>Alam....</p>\r\n\r\n<p>berikan aku versi terbaik dari dirimu, berikan aku keindahan yang sempurna yang pernah kau miliki</p>\r\n\r\n<p>Alam....</p>\r\n\r\n<p>izinkan aku menjelajahi seluruh seluk beluk beluk dari dirimu, menatap indahnya awan, menatap indahnya langit, merasakan angin, mendengar deburan ombak, semua yangkau miliki begitu sempurna</p>\r\n\r\n<p>Alam....</p>\r\n\r\n<p>katakan pada penciptamu, aku berterima kasih, aku berterima kasih karena dia telah menciptakan, membuatku menjadi lebih baik saat menatapmu alam</p>\r\n\r\n<p>Alam...</p>\r\n\r\n<p>izinkan aku mencintaimu secara sempurna</p>\r\n','alam.jpg','2022-06-03',2,NULL,2,'alam',34),(11,'Langit','<p>Langit yang hitam menjatuhkan jutaan pensil padaku, apa yang akan digambar ditubuhku, apakah rindu yang meluncur dari dingin matamu?</p>\r\n\r\n<p>T&#39;lah kubisikan namamu pada angin, semoga saja hujan mendengar dan lahir sungai abadi dari rintiknya, mengikis batu - batu dan seribu prasasti tercipta untukmu.</p>\r\n\r\n<p>&nbsp;</p>\r\n','langit.jpg','2022-06-04',2,NULL,2,'langit',38),(12,'senja yang usang','<p>Selamat tinggal adalah senja yang usang,</p>\r\n\r\n<p>kawanan bintang yang mengajarkanku,</p>\r\n\r\n<p>kita butuh kegelapan supaya bisa bersinar,</p>\r\n\r\n<p>bulan kesepian yang mengajarkanku,</p>\r\n\r\n<p>kita tetap bisa indah meski sendiri,</p>\r\n','senja_yang_usang.jpg','2022-06-03',2,NULL,2,'senja-yang-usang',47),(14,'Seorang Mahasiswa','<p>Mahasiswa adalah bagian kata dari Maha dan Siswa yang memiliki makna Maha artinya&nbsp;&ldquo;ter&rdquo; dan siswa artinya &ldquo;pelajar&rdquo;&nbsp;jadi secara pengartian mahasiswa artinya terpelajar.</p>\r\n\r\n<p>Mahasiswa juga disebut sebagai agen of chage</p>\r\n\r\n<p>Mahasiswa adalah penyambung lidah antara penguasa dan masyarakat</p>\r\n\r\n<p>Sebuah beban yang sangat berat bukan? Bagi seorang mahasiswa&hellip;</p>\r\n\r\n<p>Selain itu juga mahasiswa adalah harapan dari orang tua</p>\r\n\r\n<p>Banyak beban yang harus dipikul oleh seorang mahasiswa</p>\r\n\r\n<p>Apakah harus menyerah? Tentu tidak..</p>\r\n\r\n<p>Karna kita adalah penerus bangsa, dan itu semua harus kita lalui..</p>\r\n\r\n<p>Tidak ada kata menyerah bagi seorang mahasiswa yang mau berjuang&hellip;</p>\r\n\r\n<p>Terus semangat, terus berjuang, karna harapan bangsa ada di tangan kita&hellip;.</p>\r\n\r\n<p>Hidup mahasiswa&hellip;&hellip;..</p>\r\n','seorang_mahasiswa.jpg','2022-06-04',4,1,NULL,'seorang-mahasiswa',28),(15,'Sebuah Perjuangan dan Penantian Panjang','<p><tt>6 tahun melewati pendidikan sekolah dasar</tt></p>\r\n\r\n<p><tt>3 tahun melewati pendidikan sekolah menengah pertama</tt></p>\r\n\r\n<p><tt>3 tahun juga melewati pendidikan sekolah menengah atas</tt></p>\r\n\r\n<p><tt>Dan tibalah dihari kelulusan tiba&hellip;.</tt></p>\r\n\r\n<p><tt>Kita semua riang gembira sambil tertawa dan berbicara masa dengan yang akan dilalui</tt></p>\r\n\r\n<p><tt>Ada yang memilih melanjutkan pendidikan dan ada yang memilik pekerjaan&hellip;.</tt></p>\r\n\r\n<p><tt>Tibalah saatnya memilih masuk di bangku kuliah&hellip;.</tt></p>\r\n\r\n<p><tt>Memikirkan hal yang seru yang akan dilakukan, penuh suka duka dalam menggapai impian, kadang dihempas hingga ingin menyerah, terkadang dibawa terbang hingga tak sadarkan</tt></p>\r\n\r\n<p><tt>Bangku kuliah ternyata tidak seindah yang dibayangkan, tetapi tidak juga semenyeramkan yang orang ceritakan, karena disinilah kita memilih jalan yang ingin kita lalui</tt></p>\r\n\r\n<p><tt>Hingga tak terasa tiba pada waktunya</tt></p>\r\n\r\n<p><tt>Iya itulah yang Namanya &ldquo;Skripsi&rdquo; 7 huruf yang membuat semua orang ketakutan, memikirkan hal yang mengerikan, tetapi tak ada pilihan semuanya itu harus di jalankan</tt></p>\r\n\r\n<p><tt>Sebuah perjuangan untuk menyelesaikannya, tiada hari tanpa bersenang-senang, kehidupan yang suram, makan dan tidur yang tak nyaman, semua dibuat ketakukan olehnya</tt></p>\r\n\r\n<p><tt>Akan tetapi haruskan kita menyerah dengan hal begitu saja?</tt></p>\r\n\r\n<p><tt>Tentu tidak, karna sudah banyak hal yang kita lewatkan dari bangku SD hingga Kuliah, semua dijalankan sesuai skenario yang di inginkan tetapi diubah oleh dosen pembimbing yang membuat kita kebingungan</tt></p>\r\n\r\n<p><tt>Banyak perjuangan yang harus dijalankan, maju terus meski ombak menghadang, begitulah perumpamaannya hehe, terus lah melangkah kedepan jangan pernah melihat kebelakang&hellip;</tt></p>\r\n\r\n<p><tt>Hingga akhirnya tiba sebuah penantian yang bahagia dengan kata ACC</tt></p>\r\n\r\n<p><tt>Dan lanjut ke bagian yang menyeramkan lainnya, yaitu sidang skripsi dengan 3 dosen didepan, tetapi kembali lagi apa yang diceritakan berbeda dengan apa yang dirasakan, ketika kita mengerjakan dengan sungguh-sungguh maka hasil yang didapatkan juga sungguh-sungguh menyenangkan, begitulah yang saya rasakan</tt></p>\r\n\r\n<p><tt>Hingga tibalah akhirnya hal yang sangat menyenangkan, yaitu disahkannya sebuah gelar tambahakn di akhir nama yang membuat semua orang bangga</tt></p>\r\n\r\n<p><tt>Sebuah kebahagiaan yang tak dapat dikatakan karena inilah yang di harapkan sebagai penantian yang di inginkan</tt></p>\r\n\r\n<p><tt>Selamat datang gelar baru ku</tt></p>\r\n\r\n<p><tt>Sebuah penantian dan perjuangan yang Panjang untuk mendapatkan mu, dan tidak semenyeram yang diceritakan untuk mendapatkanmu</tt></p>\r\n\r\n<p><tt>&ldquo;jika kita bersungguh-sungguh maka hasil yang didapatkan juga menyenangkan, jangan pernah menyerah bahwasannya skripsi bukanlah hal yang susah, jika ada kemauan dan keinginan semua akan tercapai, dan satu lagi jangan pernah memikirkannya, tetapi jalankan saja sesuai skenarionya&rdquo;</tt></p>\r\n','Sebuah_Perjuangan_dan_Penantian_Panjang.jpg','2022-06-13',4,1,NULL,'sebuah-perjuangan-dan-penantian-panjang',31),(16,'Kehidupan','<p>Dalam kehidupan sering kali kita dibuat untuk</p>\r\n\r\n<p>memilih sebuah keputusan, dan seringkali</p>\r\n\r\n<p>keputusan itu membawa kita kepada hal-hal</p>\r\n\r\n<p>yang tidak terduga, beberapa hal membuat</p>\r\n\r\n<p>kita senang, dan beberapa hal membuat kita</p>\r\n\r\n<p>menyesal, tapi ketahuilah benar atau salahnya</p>\r\n\r\n<p>kita dalam membuat sebuah keputusan, pada</p>\r\n\r\n<p>akhirnya kita akan belajar untuk menjadi manusia</p>\r\n\r\n<p>yang lebih baik lagi...</p>\r\n','kehidupan.jpg','2022-06-21',2,1,NULL,'kehidupan',19);
/*!40000 ALTER TABLE `tbl_berita` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_contact`
--

DROP TABLE IF EXISTS `tbl_contact`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_contact` (
  `id_contact` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(55) DEFAULT NULL,
  `email` varchar(55) DEFAULT NULL,
  `subjek` varchar(255) DEFAULT NULL,
  `isi` text DEFAULT NULL,
  PRIMARY KEY (`id_contact`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_contact`
--

LOCK TABLES `tbl_contact` WRITE;
/*!40000 ALTER TABLE `tbl_contact` DISABLE KEYS */;
INSERT INTO `tbl_contact` VALUES (1,'Fauzan','fauzan@gmail.com','Kisah Hidup','You can browse different tags such as multi-page, resume, video, etc. to see more CSS templates. Sed hendrerit rutrum arcu, non malesuada nisi. Sed id facilisis turpis. Donec justo elit, dapibus vel ultricies in, molestie sit amet risus. In nunc augue, rhoncus sed libero et, tincidunt tempor nisl. Donec egestas, quam eu rutrum ultrices, sapien ante posuere nisl, ac eleifend eros orci vel ante. Pellentesque vitae eleifend velit. Etiam blandit felis sollicitudin vestibulum feugiat.\r\n\r\nDonec tincidunt leo nec magna gravida varius. Suspendisse felis orci, egestas ac sodales quis, venenatis et neque. Vivamus facilisis dignissim arcu et blandit. Maecenas finibus dui non pulvinar lacinia. Ut lacinia finibus lorem vel porttitor. Suspendisse et metus nec libero ultrices varius eget in risus. Cras id nibh at erat pulvinar malesuada et non ipsum. Suspendisse id ipsum leo.'),(2,'Tes','TES','TES','TES'),(3,'ss','ss','ss','ss');
/*!40000 ALTER TABLE `tbl_contact` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_kategori`
--

DROP TABLE IF EXISTS `tbl_kategori`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_kategori` (
  `id_kategori` int(11) NOT NULL AUTO_INCREMENT,
  `nama_kategori` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`id_kategori`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_kategori`
--

LOCK TABLES `tbl_kategori` WRITE;
/*!40000 ALTER TABLE `tbl_kategori` DISABLE KEYS */;
INSERT INTO `tbl_kategori` VALUES (2,'PUITIS'),(3,'PUISI'),(4,'NARASI');
/*!40000 ALTER TABLE `tbl_kategori` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_user`
--

DROP TABLE IF EXISTS `tbl_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_user` (
  `id_user` int(11) NOT NULL AUTO_INCREMENT,
  `nama_user` varchar(25) DEFAULT NULL,
  `username` varchar(25) DEFAULT NULL,
  `password` varchar(25) DEFAULT NULL,
  `foto_user` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id_user`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_user`
--

LOCK TABLES `tbl_user` WRITE;
/*!40000 ALTER TABLE `tbl_user` DISABLE KEYS */;
INSERT INTO `tbl_user` VALUES (1,'Catatan Tintaku','catatan ku','catatan','logo.png'),(2,'Lika Widiawati','Likakece','Lika12345','20220517_182249_0000.png'),(3,'Khairul Ulum','Khairul12345','Khairul12345','IMG-20220604-WA0066.jpg'),(4,'Leni Indriani','Leni@12345','Leni@12345','1654412951779.jpg'),(5,'Muhibatul marufi','Muhibatul','Muhibatul@12345','—Pngtree—muslim_teacher_wearing_hijab_illustration_6279821.png'),(6,'Nurgayah','Nurgayah','Nurgayah12345','gayah.jpg');
/*!40000 ALTER TABLE `tbl_user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-04  1:20:04
