-- MySQL dump 10.19  Distrib 10.3.32-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: fauzanr1_cvku
-- ------------------------------------------------------
-- Server version	10.3.32-MariaDB-cll-lve

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `page_views`
--

DROP TABLE IF EXISTS `page_views`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `page_views` (
  `visitor_ip` varchar(255) NOT NULL,
  `page_id` int(11) unsigned NOT NULL,
  KEY `page_id` (`page_id`),
  CONSTRAINT `page_views_ibfk_1` FOREIGN KEY (`page_id`) REFERENCES `tbl_berita` (`id_berita`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `page_views`
--

LOCK TABLES `page_views` WRITE;
/*!40000 ALTER TABLE `page_views` DISABLE KEYS */;
INSERT INTO `page_views` VALUES ('127.0.0.1',7),('103.105.30.72',7),('103.105.31.107',7),('149.154.161.13',7),('103.105.30.68',7),('103.105.31.79',7),('103.105.30.66',7),('103.105.31.117',7),('103.105.31.98',7),('54.36.149.89',7),('103.105.31.75',7),('103.105.31.106',7),('103.105.31.106',9),('103.105.31.127',9),('103.105.31.127',7),('114.125.28.225',9),('103.105.31.66',9),('103.105.31.95',9),('54.36.149.89',9),('103.105.30.119',7),('103.105.30.119',9),('125.167.57.96',7),('103.105.30.119',10),('125.167.57.96',10),('125.167.57.96',9),('103.105.31.117',9),('103.105.31.117',10),('54.36.149.89',10),('103.105.31.119',10),('103.105.31.119',7),('51.222.253.2',10),('185.189.115.22',7),('116.206.36.58',10),('116.206.36.58',9),('202.67.45.3',9),('202.67.45.3',10),('144.217.135.241',7),('144.217.135.241',9),('144.217.135.241',10),('180.242.192.98',10),('180.242.192.98',7),('51.222.253.15',7),('51.222.253.6',9),('51.222.253.20',9),('51.222.253.18',10),('51.222.253.10',10),('180.242.192.180',7),('180.242.192.180',10),('202.67.39.10',10),('54.36.149.96',7),('54.36.149.50',7),('54.36.148.159',9),('54.36.148.133',9),('54.36.149.27',9),('54.36.148.120',7),('54.36.148.90',9),('54.36.148.41',7),('54.36.148.30',10),('114.125.13.183',7),('51.222.253.11',10),('54.36.149.91',10),('182.1.35.233',7),('116.206.36.29',9),('149.56.160.194',10),('149.56.160.194',9),('149.56.160.194',7),('54.36.148.250',7),('54.36.148.246',7),('54.36.149.47',9),('54.36.148.84',9),('54.36.148.109',7),('54.36.148.224',9),('51.222.253.5',9),('51.222.253.6',7),('54.36.148.7',10),('54.36.149.54',10),('54.36.149.11',10),('159.65.24.22',10),('159.65.24.22',9),('159.65.24.22',7);
/*!40000 ALTER TABLE `page_views` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_admin`
--

DROP TABLE IF EXISTS `tbl_admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_admin` (
  `id_admin` int(11) NOT NULL AUTO_INCREMENT,
  `nama_admin` varchar(255) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `foto_admin` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id_admin`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_admin`
--

LOCK TABLES `tbl_admin` WRITE;
/*!40000 ALTER TABLE `tbl_admin` DISABLE KEYS */;
INSERT INTO `tbl_admin` VALUES (1,'Fauzan Purma R.','fauzan1234','fauzan1234','website1.jpg');
/*!40000 ALTER TABLE `tbl_admin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_berita`
--

DROP TABLE IF EXISTS `tbl_berita`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_berita` (
  `id_berita` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `judul_berita` varchar(255) DEFAULT NULL,
  `isi_berita` text DEFAULT NULL,
  `tgl_berita` date DEFAULT NULL,
  `id_admin` int(11) DEFAULT NULL,
  `id_kategori` int(11) DEFAULT NULL,
  `slug_berita` varchar(255) DEFAULT NULL,
  `total_views` int(11) unsigned NOT NULL,
  `foto_berita` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id_berita`),
  KEY `total_views` (`total_views`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_berita`
--

LOCK TABLES `tbl_berita` WRITE;
/*!40000 ALTER TABLE `tbl_berita` DISABLE KEYS */;
INSERT INTO `tbl_berita` VALUES (7,'Fauzan Purma Ramadhan','<pre>\r\nHalo Semuanya\r\n</pre>\r\n\r\n<p>Perkenalkan Saya</p>\r\n\r\n<blockquote>\r\n<p>Nama : Fauzan Purma Ramadhan</p>\r\n\r\n<p>Tempat, Tanggal Lahir: Kuala Enok, 11 Desember 2000</p>\r\n\r\n<p>Alamat : Jl. Widuri 1, Kec Kota Baru, Kota Jambi, Provinsi Jambi</p>\r\n\r\n<p>Jenis Kelamin: Laki - Laki</p>\r\n\r\n<p>Status : Lajang</p>\r\n\r\n<p>Agama : Islam</p>\r\n\r\n<p>Kewarganegaraan: Indonesia</p>\r\n\r\n<p>Jurusan: Teknik Informatika</p>\r\n\r\n<p>Universitas: Universitas Dinamika Bangsa</p>\r\n\r\n<p>Hobi: Olahraga, Membaca, Lermain Leptop</p>\r\n\r\n<p>Alamat Email: fauzanuciha7@gmail.com</p>\r\n</blockquote>\r\n\r\n<p>Saya adalah seorang sarjana teknik informatika di salah satu universitas yang berada di kota jambi (<strong><a href=\"http://unama.ac.id\">Universitas Dinamika Bangsa</a>)&nbsp;</strong>Saya Memiliki Keahlian Diantaranya Di Bidang Desain Grafis, Junior Web Programming, Microsoft Office, dan hal - hal yang bersangkutan dengan komputer ataupun digitalisasi...</p>\r\n\r\n<p>Terima Kasih</p>\r\n<!-- End Blog Section -->','2022-05-31',1,3,'fauzan-purma-ramadhan',34,'hero-bg.jpg'),(9,'Seorang Mahasiswa','<p><span style=\"font-size:11pt\"><span style=\"font-family:Calibri,\">Mahasiswa adalah bagian kata dari Maha dan Siswa yang memiliki makna M<span style=\"background-color:white\"><span style=\"color:black\">aha artinya</span></span>&nbsp;&ldquo;ter&rdquo; dan siswa artinya &ldquo;pelajar&rdquo;&nbsp;jadi secara pengartian mahasiswa artinya terpelajar.</span></span></p>\r\n\r\n<p><span style=\"font-size:11pt\"><span style=\"font-family:Calibri,\">Mahasiswa juga disebut sebagai agen of chage</span></span></p>\r\n\r\n<p><span style=\"font-size:11pt\"><span style=\"font-family:Calibri,\">Mahasiswa adalah penyambung lidah antara penguasa dan masyarakat</span></span></p>\r\n\r\n<p><span style=\"font-size:11pt\"><span style=\"font-family:Calibri,\">Sebuah beban yang sangat berat bukan? Bagi seorang mahasiswa&hellip;</span></span></p>\r\n\r\n<p><span style=\"font-size:11pt\"><span style=\"font-family:Calibri,\">Selain itu juga mahasiswa adalah harapan dari orang tua</span></span></p>\r\n\r\n<p><span style=\"font-size:11pt\"><span style=\"font-family:Calibri,\">Banyak beban yang harus dipikul oleh seorang mahasiswa</span></span></p>\r\n\r\n<p><span style=\"font-size:11pt\"><span style=\"font-family:Calibri,\">Apakah harus menyerah? Tentu tidak..</span></span></p>\r\n\r\n<p><span style=\"font-size:11pt\"><span style=\"font-family:Calibri,\">Karna kita adalah penerus bangsa, dan itu semua harus kita lalui..</span></span></p>\r\n\r\n<p><span style=\"font-size:11pt\"><span style=\"font-family:Calibri,\">Tidak ada kata menyerah bagi seorang mahasiswa yang mau berjuang&hellip;</span></span></p>\r\n\r\n<p><span style=\"font-size:11pt\"><span style=\"font-family:Calibri,\">Terus semangat, terus berjuang, karna harapan bangsa ada di tangan kita&hellip;.</span></span></p>\r\n\r\n<p><span style=\"font-size:11pt\"><span style=\"font-family:Calibri,\">Hidup mahasiswa&hellip;&hellip;..</span></span></p>\r\n','2022-06-05',1,4,'seorang-mahasiswa',19,'seorang_mahasiswa.jpg'),(10,'Sebuah Penantian dan Perjuangan Panjang','<p><tt>6 tahun melewati pendidikan sekolah dasar</tt></p>\r\n\r\n<p><tt>3 tahun melewati pendidikan sekolah menengah pertama</tt></p>\r\n\r\n<p><tt>3 tahun juga melewati pendidikan sekolah menengah atas</tt></p>\r\n\r\n<p><tt>Dan tibalah dihari kelulusan tiba&hellip;.</tt></p>\r\n\r\n<p><tt>Kita semua riang gembira sambal tertawa dan berbicara masa dengan yang akan dilalui</tt></p>\r\n\r\n<p><tt>Ada yang memilih melanjutkan pendidikan dan ada yang memilik pekerjaan&hellip;.</tt></p>\r\n\r\n<p><tt>Tibalah saatnya memilih masuk di bangku kuliah&hellip;.</tt></p>\r\n\r\n<p><tt>Memikirkan hal yang seru yang akan dilakukan, penuh suka duka dalam menggapai impian, kadang dihempas hingga ingin menyerah, terkadang dibawa terbang hingga tak sadarkan</tt></p>\r\n\r\n<p><tt>Bangku kuliah ternyata tidak seindah yang dibayangkan, tetapi tidak juga semenyeramkan yang orang ceritakan, karena disinilah kita memilih jalan yang ingin kita lalui</tt></p>\r\n\r\n<p><tt>Hingga tak terasa tiba pada waktunya</tt></p>\r\n\r\n<p><tt>Iya itulah yang Namanya &ldquo;Skripsi&rdquo; 7 huruf yang membuat semua orang ketakutan, memikirkan hal yang mengerikan, tetapi tak ada pilihan semuanya itu harus di jalankan</tt></p>\r\n\r\n<p><tt>Sebuah perjuangan untuk menyelesaikannya, tiada hari tanpa bersenang-senang, kehidupan yang suram, makan dan tidur yang tak nyaman, semua dibuat ketakukan olehnya</tt></p>\r\n\r\n<p><tt>Akan tetapi haruskan kita menyerah dengan hal begitu saja?</tt></p>\r\n\r\n<p><tt>Tentu tidak, karna sudah banyak hal yang kita lewatkan dari bangku SD hingga Kuliah, semua dijalankan sesuai skenario yang di inginkan tetapi diubah oleh dosen pembimbing yang membuat kita kebingungan</tt></p>\r\n\r\n<p><tt>Banyak perjuangan yang harus dijalankan, maju terus meski ombak menghadang, begitulah perumpamaannya hehe, terus lah melangkah kedepan jangan pernah melihat kebelakang&hellip;</tt></p>\r\n\r\n<p><tt>Hingga akhirnya tiba sebuah penantian yang bahagia dengan kata ACC</tt></p>\r\n\r\n<p><tt>Dan lanjut ke bagian yang menyeramkan lainnya, yaitu sidang skripsi dengan 3 dosen didepan, tetapi kembali lagi apa yang diceritakan berbeda dengan apa yang dirasakan, ketika kita mengerjakan dengan sungguh-sungguh maka hasil yang didapatkan juga sungguh-sungguh menyenangkan, begitulah yang saya rasakan</tt></p>\r\n\r\n<p><tt>Hingga tibalah akhirnya hal yang sangat menyenangkan, yaitu disahkannya sebuah gelar tambahakn di akhir nama yang membuat semua orang bangga</tt></p>\r\n\r\n<p><tt>Sebuah kebahagiaan yang tak dapat dikatakan karena inilah yang di harapkan sebagai penantian yang di inginkan</tt></p>\r\n\r\n<p><tt>Selamat datang gelar baru ku</tt></p>\r\n\r\n<p><tt>Sebuah penantian dan perjuangan yang Panjang untuk mendapatkan mu, dan tidak semenyeram yang diceritakan untuk mendapatkanmu</tt></p>\r\n\r\n<p><tt>&ldquo;jika kita bersungguh-sungguh maka hasil yang didapatkan juga menyenangkan, jangan pernah menyerah bahwasannya skripsi bukanlah hal yang susah, jika ada kemauan dan keinginan semua akan tercapai, dan satu lagi jangan pernah memikirkannya, tetapi jalankan saja sesuai skenarionya&rdquo;</tt></p>\r\n','2022-06-07',1,4,'sebuah-penantian-dan-perjuangan-panjang',22,'Sebuah_Perjuangan_dan_Penantian_Panjang.jpg');
/*!40000 ALTER TABLE `tbl_berita` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_contact`
--

DROP TABLE IF EXISTS `tbl_contact`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_contact` (
  `id_contact` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(50) DEFAULT NULL,
  `email` varchar(25) DEFAULT NULL,
  `subjek` varchar(50) DEFAULT NULL,
  `text` text DEFAULT NULL,
  PRIMARY KEY (`id_contact`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_contact`
--

LOCK TABLES `tbl_contact` WRITE;
/*!40000 ALTER TABLE `tbl_contact` DISABLE KEYS */;
INSERT INTO `tbl_contact` VALUES (4,'AnnaEl','annaEl@mail.com','Ι want to mеet sеrіous mаn... (:','Ηеllо аll, guys! I know, my mesѕаge maу bе tоo ѕpeсіfiс,\r\nВut my ѕister fоund nісe mаn hеrе аnd they mаrried, ѕо hоw аbout mе?ǃ :)\r\nΙ аm 23 уeаrѕ old, Αnna, frоm Romanіа, Ι knоw Εnglіsh аnd Germаn languаgeѕ also\r\nАnd... Ι hаvе speсіfіc diѕeаѕе, nаmеd nymрhоmаniа. Ԝhо know whаt is thіs, саn undеrѕtand me (better tо ѕaу it іmmediаtelу)\r\nΑh yes, I соok vеrу tastу! and I lovе not only соok ;))\r\nΙm rеal girl, not prоstitutе, аnd loоking for ѕerіоuѕ and hоt rеlаtіonship...\r\nΑnуwaу, yоu сan find my prоfіle here: http://toscware.ga/user/93852/ \r\n'),(5,'CynthiaMeack','vietatof123@gmail.com','Help the Ukrainian army','How to help Ukraine and its people stand against Putin and the Russian attack \r\nFor volunteers and organizations in other countries who are collecting supplies to deliver to Ukraine, this official website https://www.helpukraine.center/ contains the information about what supplies are needed the most, the address of the drop-off center, and instructions for how to pack medical supplies. English version of the website is temporarily unavailable, but you may find their 24/7 call-center phone numbers as well as the address of the drop-off center in Poland at the bottom of the webpage. \r\n \r\nThis document provides information about volunteers across Europe who are collecting supplies for your region or nearby regions. If you would like to donate to these groups or offer your help, please connect with them directly. \r\n \r\nRussia’s President, Vladimir Putin, has ordered a military attack that continues to claim the lives of innocent and peaceful Ukrainian citizens. \r\n \r\nThe situation in Ukraine is dire and urgent, which is why we must commit to helping Ukrainian non-profits and charities conduct relief efforts. One of the most effective ways to help Ukraine and its citizens is donating to Ukrainian relief and humanitarian efforts. Right now, the people of Ukraine are facing an unprecedented attack on their country, freedoms, and families. \r\nWe have compiled a list of trusted and verified Ukrainian non-profits who need funds to help children, families, and local citizens mitigate the violent attacks Russia has unleashed. 100% of your donation will go to local Ukrainian non-profits and relief efforts. Don’t forget to share this page with your friends, family, and social networks after donating. \r\n \r\nPlease consider donating anything you can to the following Ukrainian non-profits — they are counting on our support during one of the darkest hours in recent history. \r\nAttention: there is a shortage of critical non-lethal army supplies in Ukraine - body armor vests, helmets, radios, first aid kits, etc. All body armor vests that were in Ukraine have already been given to the army. One of the best ways to help right now is to support volunteers outside of Ukraine who are collecting the necessary supplies in their countries and delivering them directly to the Ukrainian volunteers at the border. If you can, please consider donating to this fundraiser in Poland. They have just delivered the first batch of critical supplies: helmets (210 pcs) and vests (70 pcs) to Ukraine. The donations are collected in Poland zloty currency, 10 USD ~ 41 zl (PLN). Your bank will do the currency conversion automatically. The website is in Polish and the interface is not quite intuitive, the easiest way to make a payment may be to open the link on your computer and use Google translate in Chrome. \r\nIf you are a business or an individual located in Poland, Slovakia, Hungary, or Romania and willing to help collecting supplies that are most needed in Ukraine right now, please fill out this form. We will contact you and help to coordinate reception at the Ukrainian border. This document contains a list of supplies that are needed the most at this time. \r\nUrgent humanitarian help for Ukraine \r\n \r\n \r\nTo credit funds in national currency: \r\n \r\nBank: National Bank of Ukraine \r\nМФО 300001 \r\nРахунок № UA843000010000000047330992708 \r\nкод ЄДРПОУ 00032106 \r\nОтримувач: Національний банк України Для зарахування коштів у USD: BENEFICIARY: National Bank of Ukraine \r\nBENEFICIARY BIC: NBUA UA UX \r\nBENEFICIARY ADDRESS: 9 Instytutska St, Kyiv, 01601, Ukraine \r\nACCOUNT NUMBER: 400807238 \r\nBENEFICIARY BANK NAME: JP MORGAN CHASE BANK, New York \r\nBENEFICIARY BANK BIC: CHASUS33 \r\nABA 0210 0002 1 \r\nBENEFICIARY BANK ADDRESS: 383 Madison Avenue, New York, NY 10017, USA \r\nPURPOSE OF PAYMENT: for ac 47330992708 \r\nДля зарахування коштів у EUR: \r\n \r\nBENEFICIARY: National Bank of Ukraine \r\nIBAN DE05504000005040040066 \r\nPURPOSE OF PAYMENT: for ac 47330992708 \r\nBENEFICIARY BANK NAME: DEUTSCHE  BUNDESBANK, Frankfurt \r\nBENEFICIARY BANK BIC: MARKDEFF \r\nBENEFICIARY BANK ADDRESS: Wilhelm-Epstein-Strasse 14, 60431 Frankfurt Am Main, Germany \r\n \r\nДля зарахування коштів у GBP: BENEFICIARY/RECIPIENT NAME: National Bank of Ukraine \r\nACCOUNT NUMBER: 80033041 \r\nIBAN GB52CHAS60924280033041 \r\nBENEFICIARY ADDRESS: 9 Instytutska St, Kyiv, 01601, Ukraine \r\nBENEFICIARY BANK NAME: JP MORGAN CHASE BANK NA, London \r\nBENEFICIARY BANK BIC: CHASGB2L \r\nSORT CODE: 60-92-42 \r\nBENEFICIARY BANK ADDRESS: 125 London Wall, London EC2Y 5AJ, UK PURPOSE OF PAYMENT: for ac 47330992708 Для зарахування коштів у AUD: BENEFICIARY: National Bank of Ukraine \r\nBENEFICIARY BIC: NBUA UA UX \r\nBENEFICIARY ADDRESS: 9 Instytutska St, Kyiv, 01601, Ukraine \r\nACCOUNT NUMBER: 817532 \r\nBSB code 092-002 \r\nBENEFICIARY BANK NAME: RESERVE  BANK OF AUSTRALIA, Sydney \r\nBENEFICIARY BANK BIC: RSBKAU2S \r\nBENEFICIARY BANK ADDRESS: GPO Box 3947, Sydney NSW 2000, Australia \r\nPURPOSE OF PAYMENT: for ac 47330992708 Для зарахування коштів у CAD: \r\nBENEFICIARY: National Bank of Ukraine \r\nBENEFICIARY BIC: NBUA UA UX \r\nBENEFICIARY ADDRESS: 9 Instytutska St, Kyiv, 01601, Ukraine \r\nACCOUNT NUMBER: 3144-1044-166 \r\nBENEFICIARY BANK NAME: BANK OF MONTREAL, Toronto \r\nBENEFICIARY BANK BIC: BOFMCAM2 \r\nBENEFICIARY BANK ADDRESS: 100 King Street West, 24th Floor, Toronto, Ontario, M5X 1A9, Canada \r\nPURPOSE OF PAYMENT: for ac 47330992708 \r\n \r\n \r\nДля зарахування коштів у PLN: \r\n \r\nBENEFICIARY: National Bank of Ukraine \r\nBENEFICIARY BIC: NBUA UA UX \r\nBENEFICIARY ADDRESS: 9 Instytutska St, Kyiv, 01601, Ukraine \r\nACCOUNT NUMBER: PL91113000070080239435200002 \r\nBENEFICIARY BANK NAME: Bank Gospodarstwa Krajowego \r\nBENEFICIARY BANK BIC: GOSKPLPW \r\nBENEFICIARY BANK ADDRESS: Al. Jerozolimskie 7, 00-955 Warszawa, Polska (temporary address: Chmielna 73, 00-801 Warszawa, Polska) \r\nPURPOSE OF PAYMENT: for ac 47330992708 \r\n \r\nhttps://bank.gov.ua/ua/news/all/natsionalniy-bank-vidkriv-spetsrahunok-dlya-zboru-koshtiv-na-potrebi-armiyi'),(6,'ad','ad','ad','adad'),(7,'GhloSkils','pertitferwer@outlook.com','My cunt is horny right now. Make me squirt','My pussy is not just flowing heavily, I\'m pouring all over. If you don\'t fuck her, she squirts https://first-dating.top/yotube/?u=wh5kd06&o=qxpp80k'),(8,'','','','');
/*!40000 ALTER TABLE `tbl_contact` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_cv`
--

DROP TABLE IF EXISTS `tbl_cv`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_cv` (
  `id_cv` int(11) NOT NULL AUTO_INCREMENT,
  `nama_cv` varchar(25) DEFAULT NULL,
  `file_cv` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id_cv`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_cv`
--

LOCK TABLES `tbl_cv` WRITE;
/*!40000 ALTER TABLE `tbl_cv` DISABLE KEYS */;
INSERT INTO `tbl_cv` VALUES (1,'CV 17 JULY 2022','resum.jpg');
/*!40000 ALTER TABLE `tbl_cv` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_depan`
--

DROP TABLE IF EXISTS `tbl_depan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_depan` (
  `id_depan` int(11) NOT NULL AUTO_INCREMENT,
  `nama_depan` varchar(20) DEFAULT NULL,
  `foto_depan` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id_depan`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_depan`
--

LOCK TABLES `tbl_depan` WRITE;
/*!40000 ALTER TABLE `tbl_depan` DISABLE KEYS */;
INSERT INTO `tbl_depan` VALUES (1,'CV - FAUZAN','zan.png');
/*!40000 ALTER TABLE `tbl_depan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_fotofortopolio`
--

DROP TABLE IF EXISTS `tbl_fotofortopolio`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_fotofortopolio` (
  `id_fotofortopolio` int(11) NOT NULL AUTO_INCREMENT,
  `id_namafortopolio` int(11) DEFAULT NULL,
  `nama_foto` varchar(50) DEFAULT NULL,
  `foto` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id_fotofortopolio`)
) ENGINE=InnoDB AUTO_INCREMENT=119 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_fotofortopolio`
--

LOCK TABLES `tbl_fotofortopolio` WRITE;
/*!40000 ALTER TABLE `tbl_fotofortopolio` DISABLE KEYS */;
INSERT INTO `tbl_fotofortopolio` VALUES (12,2,'Pioneer Residence','21.jpg'),(13,1,'Nuraini Tasari','3.jpg'),(14,2,'Sistem Informasi Akademik','siakad.jpg'),(15,9,'Visi Misi','web5.JPG'),(16,9,'berita','web_3.JPG'),(17,9,'galeri','web_4.JPG'),(18,9,'depan','web_2.JPG'),(19,9,'login','web6.JPG'),(20,9,'admin','web_7.JPG'),(21,10,'1','web_1.JPG'),(22,10,'2','web_21.JPG'),(23,10,'3','web_41.JPG'),(24,10,'4','web_5.JPG'),(25,10,'5','web_6.JPG'),(26,10,'6','web_71.JPG'),(27,10,'7','web_8.JPG'),(28,10,'9','web_9.JPG'),(29,10,'11','wen_9.JPG'),(30,11,'Filosofi','kabinet_serasi_filosofi.jpg'),(31,12,'1','mon_1.jpg'),(32,12,'2','mon_2.jpg'),(35,12,'5','mon_6.jpg'),(37,12,'8','mon_8.jpg'),(38,13,'filosofi','filosofi_OKP.jpg'),(39,14,'1','log_1.jpg'),(40,14,'2','log_2.jpg'),(41,14,'3','log_3.jpg'),(42,14,'4','log_4.jpg'),(43,14,'5','log_5.jpg'),(44,14,'6','log_6.jpg'),(45,14,'7','log_7.jpg'),(46,14,'8','log_8.jpg'),(47,14,'9','log_9.jpg'),(48,14,'10','log_10.jpg'),(49,14,'11','log_11.jpg'),(51,12,'4','mon_5.jpg'),(53,12,'12','mon_9.jpg'),(55,12,'14','mon_11.jpg'),(56,12,'15','mon_7.jpg'),(57,12,'3','mon_3.jpg'),(58,12,'q','mon_10.jpg'),(59,15,'1','vektor_1.jpg'),(60,15,'2','vektor_2.jpg'),(61,15,'3','vektor_3.jpg'),(62,15,'4','vektor_4.jpg'),(63,15,'5','vektor_5.jpg'),(64,15,'6','vektor_6.jpg'),(65,16,'1','web_siakad_2.JPG'),(66,16,'2','web_siakad_3.JPG'),(67,16,'3','web_siakad_4.JPG'),(68,16,'5','web_siakad_5.JPG'),(69,16,'6','web_siakad_6.JPG'),(70,16,'7','web_siakad_7.JPG'),(71,16,'8','web_siakad_8.JPG'),(72,16,'9','web_siakad_9.JPG'),(73,16,'10','web_siakad_10.JPG'),(74,16,'11','web_siakad_11.JPG'),(75,16,'12','web_siakad_12.JPG'),(76,16,'13','web_siakad_13.JPG'),(77,16,'14','web_siakad_14.JPG'),(78,16,'15','web_siakad_15.JPG'),(79,12,'12','mon_12.jpg'),(80,17,'1','web_catatan_1.JPG'),(81,17,'2','web_catatan_2.JPG'),(82,17,'3','web_catatan_3.JPG'),(83,17,'4','web_catatan_4.JPG'),(84,18,'1','web_porto_1.JPG'),(85,18,'2','web_porto_2.JPG'),(86,18,'3','web_porto_3.JPG'),(87,18,'4','web_porto_4.JPG'),(88,18,'5','web_porto_5.JPG'),(89,18,'6','web_porto_6.JPG'),(90,18,'7','web_porto_7.JPG'),(91,18,'8','web_porto_8.JPG'),(92,18,'9','web_porto_9.JPG'),(93,17,'5','web_catatan_5.JPG'),(94,17,'6','web_catatan_6.JPG'),(95,19,'1','web_company_1.JPG'),(96,19,'2','web_company_2.JPG'),(97,19,'3','web_company_3.JPG'),(98,19,'4','web_company_4.JPG'),(99,19,'5','web_company_5.JPG'),(100,19,'6','web_company_6.JPG'),(101,19,'7','web_company_7.JPG'),(102,19,'8','web_company_8.JPG'),(103,19,'9','web_company_9.JPG'),(104,19,'10','web_company_10.JPG'),(105,19,'11','web_company_11.JPG'),(106,20,'1','tb_2.jpg'),(107,20,'2','tb_3.jpg'),(108,20,'3','tb_4.jpg'),(109,20,'5','tb_5.jpg'),(110,20,'6','tb_6.jpg'),(111,21,'1','uin_bkt_1.jpg'),(112,21,'2','uin_bkt_2.jpg'),(113,21,'3','uin_bkt_3.jpg'),(114,21,'4','uin_bkt_4.jpg'),(115,22,'1','uin_syahada_1.jpg'),(116,22,'2','uin_syahada_2.jpg'),(117,22,'3','uin_syahada_3.jpg'),(118,22,'5','uin_syahada_4.jpg');
/*!40000 ALTER TABLE `tbl_fotofortopolio` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_kategori`
--

DROP TABLE IF EXISTS `tbl_kategori`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_kategori` (
  `id_kategori` int(11) NOT NULL AUTO_INCREMENT,
  `nama_kategori` varchar(55) DEFAULT NULL,
  PRIMARY KEY (`id_kategori`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_kategori`
--

LOCK TABLES `tbl_kategori` WRITE;
/*!40000 ALTER TABLE `tbl_kategori` DISABLE KEYS */;
INSERT INTO `tbl_kategori` VALUES (1,'Artikel'),(2,'Ungkapan'),(3,'Biodata'),(4,'Narasi');
/*!40000 ALTER TABLE `tbl_kategori` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_kemampuan`
--

DROP TABLE IF EXISTS `tbl_kemampuan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_kemampuan` (
  `id_kemampuan` int(11) NOT NULL AUTO_INCREMENT,
  `kemampuan` varchar(50) DEFAULT NULL,
  `presentasi` varchar(4) DEFAULT NULL,
  PRIMARY KEY (`id_kemampuan`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_kemampuan`
--

LOCK TABLES `tbl_kemampuan` WRITE;
/*!40000 ALTER TABLE `tbl_kemampuan` DISABLE KEYS */;
INSERT INTO `tbl_kemampuan` VALUES (1,'PHP','50'),(2,'HTML + CSS','46'),(3,'Corel Draw','70'),(4,'Photoshop','90'),(6,'Ms. Office','80'),(7,'Adobe Primer','50'),(8,'Adobe Ilustrator','50'),(9,'Freamwork CI3','70');
/*!40000 ALTER TABLE `tbl_kemampuan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_logo`
--

DROP TABLE IF EXISTS `tbl_logo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_logo` (
  `id_logo` int(11) NOT NULL AUTO_INCREMENT,
  `nama_logo` varchar(25) DEFAULT NULL,
  `foto_logo` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id_logo`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_logo`
--

LOCK TABLES `tbl_logo` WRITE;
/*!40000 ALTER TABLE `tbl_logo` DISABLE KEYS */;
INSERT INTO `tbl_logo` VALUES (1,'Excel','pngwing_com(9).png'),(2,'Word','pngwing_com(10).png'),(3,'Power Point','pngwing_com(11).png'),(4,'Corel Draw','kisspng-coreldraw-computer-software-vector-graphics-practica-corel-draw-5c65b310ca9ce8_1261320815501688488299.png'),(5,'Photoshop','NicePng_hand-drawn-frame-png_4075705.png');
/*!40000 ALTER TABLE `tbl_logo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_namafortopolio`
--

DROP TABLE IF EXISTS `tbl_namafortopolio`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_namafortopolio` (
  `id_namafortopolio` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(50) DEFAULT NULL,
  `foto_porto` varchar(255) DEFAULT NULL,
  `kategori` varchar(55) DEFAULT NULL,
  `date` varchar(255) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id_namafortopolio`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_namafortopolio`
--

LOCK TABLES `tbl_namafortopolio` WRITE;
/*!40000 ALTER TABLE `tbl_namafortopolio` DISABLE KEYS */;
INSERT INTO `tbl_namafortopolio` VALUES (9,'Website Ikatan Pelajar Mahasiswa Riau - Jambi','web_ipmr.jpg','Website','2021-09-07','www.ipmrjambi.my.id'),(10,'Website Perumahan Pioneer Residence','web_pioner.jpg','Website','2022-02-23','-'),(11,'Kabinet Serasi BEM KM UNAMA','kabinet_serasi.jpg','Logo Desain','2021-09-14','-'),(12,'Monumen / Gedung Vektor','mon_4.jpg','Vektor Art','2020-06-10','-'),(13,'Organisasi Kempas Mengabdi','OKP.jpg','Logo Desain','2021-09-15','-'),(14,'Desaign Logo - Logo Vektor','log.jpg','Logo Desain','2022-05-03','-'),(15,'Vektor Art','vektor.jpg','Vektor','2022-05-10','-'),(16,'Website Siakad MTsN 5 Muaro Jambi','web_siakad.JPG','Website','2021-09-15','-'),(17,'Website Catatan Tintaku','web_catatan.jpg','Website Cerita','2022-06-04','catatan-tintaku.xyz'),(18,'Website Portopolio (curriculum vitae (CV))','web_porto.jpg','Website Portopolio','2022-06-05','-'),(19,'Website Company Profile','web_company.JPG','Website','2022-06-16','-'),(20,'TB BABAH SAMIJAYA','tb_1.jpg','Rebranding Logo','2022-06-20','-'),(21,'UIN SJECH M. DJAMIL DJAMBEK','uin_bkt.jpg','Rebranding/Sayembara Logo','2022-07-01','-'),(22,'UIN SYAHADA PADANGSIDIMPUAN','uin_syahada.jpg','Rebranding/Sayembara Logo','2022-07-01','-');
/*!40000 ALTER TABLE `tbl_namafortopolio` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_organisasi`
--

DROP TABLE IF EXISTS `tbl_organisasi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_organisasi` (
  `id_organisasi` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(100) DEFAULT NULL,
  `jabatan` varchar(50) DEFAULT NULL,
  `tahun` varchar(50) DEFAULT NULL,
  `foto_organisasi` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id_organisasi`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_organisasi`
--

LOCK TABLES `tbl_organisasi` WRITE;
/*!40000 ALTER TABLE `tbl_organisasi` DISABLE KEYS */;
INSERT INTO `tbl_organisasi` VALUES (2,'BPH IKATAN PELAJAR MAHASISWA RIAU (IPMR) - JAMBI','STAFF KOMINFO','2019 - 2021','ipmr.png'),(3,'HIMASUGA','KOMINFO','2020 - 2021','himasuga.png'),(6,'PK KNPI KEMPAS','KOMISI KOMUNIKASI DAN INFORMASI','2020','knpi1.png'),(7,'BEM KM UNAMA','STAFF PSDM','2021 - 2022','bem.png'),(8,'BPH IKATAN PELAJAR MAHASISWA RIAU (IPMR) - JAMBI','SEKRETARIS UMUM','2021 - 2023','ipmr.png'),(9,'HIMASUGA','SEKRETARIS','2021 - 2022','himasuga.png');
/*!40000 ALTER TABLE `tbl_organisasi` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_pribadi`
--

DROP TABLE IF EXISTS `tbl_pribadi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_pribadi` (
  `id_pribadi` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(50) DEFAULT NULL,
  `presentasi` varchar(4) DEFAULT NULL,
  PRIMARY KEY (`id_pribadi`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_pribadi`
--

LOCK TABLES `tbl_pribadi` WRITE;
/*!40000 ALTER TABLE `tbl_pribadi` DISABLE KEYS */;
INSERT INTO `tbl_pribadi` VALUES (1,'Kreatifitas','80'),(2,'Komunikasi','80'),(3,'Organisasi','80'),(4,'Komitmen','80'),(5,'Kerja TIM','80');
/*!40000 ALTER TABLE `tbl_pribadi` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_profil`
--

DROP TABLE IF EXISTS `tbl_profil`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_profil` (
  `id_profil` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(50) DEFAULT NULL,
  `nama_belakang` varchar(50) DEFAULT NULL,
  `deskripsi` varchar(255) DEFAULT NULL,
  `keahlian` varchar(255) DEFAULT NULL,
  `from` varchar(50) DEFAULT NULL,
  `age` int(3) DEFAULT NULL,
  `gender` enum('Laki-Laki','Perempuan') DEFAULT NULL,
  `foto_profil` varchar(255) DEFAULT NULL,
  `live` varchar(50) DEFAULT NULL,
  `nama_cv` varchar(25) DEFAULT NULL,
  `file_cv` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id_profil`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_profil`
--

LOCK TABLES `tbl_profil` WRITE;
/*!40000 ALTER TABLE `tbl_profil` DISABLE KEYS */;
INSERT INTO `tbl_profil` VALUES (1,'Fauzan Purma ','Ramadhan','Saya Merupakan Lulusan S1 Teknik Informatika di Universitas Dinamika Bangsa Jambi, Saya mempunyai keahlian sertifikasi Microsoft Technology Association (MTA) Dan Saya Memiliki Keahlian Diantaranya Di Bidang Desain Grafis, Web Programming, Microsoft Office','Desain Grafis, Junior Web Programer, Networking','Tembilahan, Riau',21,'Laki-Laki','SS.jpg','Jambi City',NULL,NULL);
/*!40000 ALTER TABLE `tbl_profil` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_sekolah`
--

DROP TABLE IF EXISTS `tbl_sekolah`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_sekolah` (
  `id_sekolah` int(11) NOT NULL AUTO_INCREMENT,
  `tahun` varchar(50) DEFAULT NULL,
  `jurusan` varchar(50) DEFAULT NULL,
  `sekolah` varchar(50) DEFAULT NULL,
  `foto_sekolah` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id_sekolah`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_sekolah`
--

LOCK TABLES `tbl_sekolah` WRITE;
/*!40000 ALTER TABLE `tbl_sekolah` DISABLE KEYS */;
INSERT INTO `tbl_sekolah` VALUES (2,'2005-2006',NULL,'TADIKA PURI','tk.png'),(3,'2006 - 2012','-','SD Negeri 008 Sungai Gantang','sd.png'),(4,'2012 - 2015','-','MTS Sullamul Ulum','mts.png'),(5,'2015 - 2018','Jurusan Teknik Komputer dan Jaringan','SMK Negeri 1 Kempas','smk1.png'),(6,'2018 - 2022','Jurusan Teknik Informatika','Universitas Dinamika Bangsa Jambi','unama1.png');
/*!40000 ALTER TABLE `tbl_sekolah` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_sertifikat`
--

DROP TABLE IF EXISTS `tbl_sertifikat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_sertifikat` (
  `id_sertifikat` int(11) NOT NULL AUTO_INCREMENT,
  `nama_sertifikat` varchar(25) DEFAULT NULL,
  `foto_sertifikat` varchar(255) DEFAULT NULL,
  `dari` varchar(55) DEFAULT NULL,
  PRIMARY KEY (`id_sertifikat`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_sertifikat`
--

LOCK TABLES `tbl_sertifikat` WRITE;
/*!40000 ALTER TABLE `tbl_sertifikat` DISABLE KEYS */;
INSERT INTO `tbl_sertifikat` VALUES (1,'Mahir Photoshop','certificate.png','Indimart');
/*!40000 ALTER TABLE `tbl_sertifikat` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-04  1:20:05
